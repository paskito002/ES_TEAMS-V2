<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
<h1 align="center"> ᴇꜱ ᴛᴇᴀᴍꜱ👑 3.𝟎.𝟎 </h1>

- Based on **[Gifted-Baileys](https://www.npmjs.com/package/gifted-baileys)** and **[Gifted-Api](https://api.giftedtechnexus.co.ke)**
- **[Contact Me](https://t.me/mouricedevs)** for premium api keys without limitations.
- Deploy Using Creds.json/Session ID fron replit(Has no Issues)

  <a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

<details>
<summary>𝐕𝐈𝐄𝐖 𝐂𝐇𝐀𝐍𝐆𝐄𝐋𝐎𝐆</summary>
  
- 𝑩𝒐𝒕 𝑭𝒖𝒍𝒍𝒚 𝑩𝒖𝒕𝒕𝒐𝒏𝒆𝒅😎.
- 𝑨𝒍𝒍 𝑫𝒐𝒘𝒏𝒍𝒐𝒂𝒅𝒆𝒓𝒔 𝑭𝒊𝒙𝒆𝒅 𝒂𝒏𝒅 𝒂𝒓𝒆 𝑾𝒐𝒓𝒌𝒊𝒏𝒈🔥.
- 𝑨𝒅𝒅𝒆𝒅 𝑴𝒐𝒓𝒆 𝑫𝒆𝒑𝒍𝒐𝒚𝒎𝒆𝒏𝒕 𝑺𝒊𝒕𝒆𝒔🐐.
- 𝑨𝒅𝒅𝒆𝒅 𝑴𝒐𝒓𝒆 𝑫𝒆𝒑𝒍𝒐𝒚𝒎𝒆𝒏𝒕 𝑻𝒖𝒕𝒐𝒓𝒊𝒂𝒍𝒔💜.
- 𝑶𝒗𝒆𝒓𝒂𝒍 𝑷𝒆𝒓𝒇𝒐𝒓𝒎𝒂𝒏𝒄𝒆 𝑰𝒎𝒑𝒓𝒐𝒗𝒆𝒎𝒆𝒏𝒕𝒔🤫.

</details>

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

  <p align="center">
<a href="https://github.com/mouricedevs"><img title="GITHUB" src="https://img.shields.io/badge/GITHUB-GIFTED TECH-red.svg?style=for-the-badge&logo=github"></a>
<p/>
<p align="center">
<a href="https://github.com/mouricedevs?tab=followers"><img title="Followers" src="https://img.shields.io/github/followers/mouricedevs?label=Followers&style=social"></a>
<a href="https://github.com/mouricedevs/gifted/stargazers/"><img title="STARS" src="https://img.shields.io/github/stars/mouricedevs/gifted?&style=social"></a>
<a href="https://github.com/mouricedevs/gifted/network/members"><img title="Forks" src="https://img.shields.io/github/forks/mouricedevs/gifted?style=social"></a>
<a href="https://github.com/mouricedevs/gifted/watchers"><img title="Watching" src="https://img.shields.io/github/watchers/mouricedevs/gifted?label=Watching&style=social"></a>

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
  
## 𝟏. 𝐒𝐄𝐓 𝐔𝐏:

**👇FORK REPO(A MUST)**
<details>
<summary>𝗖𝗟𝗜𝗖𝗞 𝗛𝗘𝗥𝗘</summary>
  
- This is essential for you to obtain an editable repo to **[upload](https://github.com/mouricedevs/gifted/tree/main/session)** your creds.json file

<a href="https://github.com/mouricedevs/gifted/fork"><img src="https://img.shields.io/badge/CLICK%20HERE-purple" alt="FORK GIFTED-MD" width="150"></a>
</details>

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

### 𝟐. 𝐋𝐈𝐍𝐊 𝐖𝐈𝐓𝐇 𝐖𝐇𝐀𝐓𝐒𝐀𝐏𝐏

<details>
<summary>GET YOUR SESSION_ID</summary>
<a href="https://web.giftedtechnexus.co.ke/bots/giftedmd/sessions/"><img src="https://img.shields.io/badge/CLICK%20HERE-green" alt="Pairing Code" width="150"></a>

- Session ID must start with **Gifted~** and is 15 characters in length.
</details>

**OR**

<details>
<summary>GET YOUR CREDS.JSON FILE</summary>

<a href="https://web.giftedtechnexus.co.ke/bots/giftedmd/sessions/"><img src="https://img.shields.io/badge/CLICK%20HERE-blue" alt="Pairing Code" width="150"></a>

</details>

- Then **[Upload](https://github.com/mouricedevs/gifted/tree/main/session)** your creds.json file in the **[session folder](https://github.com/mouricedevs/gifted/tree/main/session)**

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

### 𝟑. 𝐃𝐄𝐏𝐋𝐎𝐘𝐌𝐄𝐍𝐓 𝐒𝐄𝐂𝐓𝐈𝐎𝐍:
**(A) HEROKU DEPLOYMENT**

<details>
<summary>CREDS.JSON DEPLOY</summary>
  
- After you've **[uploaded your creds.json](https://github.com/mouricedevs/gifted/tree/main/session),** create a new heroku app, link your github, connect the repo you've uploaded your session file then click on deploy.

<a href="https://signup.heroku.com/login"><img src="https://img.shields.io/badge/HEROKU%20SIGNUP-purple" alt="Pairing Code" width="150"></a>

<a href="https://youtu.be/3NpmjBUUBUc"><img src="https://img.shields.io/badge/WATCH%20TUTORIAL-white" alt="Pairing Code" width="150"></a>
  
```
https://dashboard.heroku.com/new?template=https://github.com/mouricedevs/gifted
```

</details>

<details>
<summary>SESSION_ID DEPLOY</summary>
<a href="https://signup.heroku.com/login"><img src="https://img.shields.io/badge/HEROKU%20SIGNUP-white" alt="Pairing Code" width="150"></a>
  
<a href="https://web.giftedtechnexus.co.ke/deploy/platforms/heroku"><img src="https://img.shields.io/badge/DEPLOY%20NOW-red" alt="Pairing Code" width="150"></a>
</details>

  
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

**(B) RENDER DEPLOYMENT**
<details>
<summary>CLICK FOR MORE</summary>
<a href="https://dashboard.render.com/signup"><img src="https://img.shields.io/badge/RENDER%20SIGNUP-green" alt="Render" width="150"></a>

<a href="https://youtu.be/TVu8CQPPliM?feature=shared"><img src="https://img.shields.io/badge/WATCH%20TUTORIAL-red" alt="Render Tutorial" width="150"></a>
</details>

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

**(C) GITHUB DEPLOYMENT**
<details>
<summary>CLICK FOR MORE</summary>
<a href="https://youtu.be/0JiVJy7AzwI?feature=shared"><img src="https://img.shields.io/badge/WATCH%20TUTORIAL-yellow" alt="Github Tutorial" width="150"></a>
</details>

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

**(D) KOYEB DEPLOYMENT**
<details>
<summary>CLICK FOR MORE</summary>
<a href="https://app.koyeb.com/auth/signup"><img src="https://img.shields.io/badge/KOYEB%20SIGNUP-purple" alt="Koyeb" width="150"></a>

<a href="https://app.koyeb.com/services/deploy/?type=git&repository=github.com%2Fmouricedevs%2Fgifted&branch=main&name=gifted-md&builder=dockerfile&env%5BAUTO_BLOCK=false%5D=&env%5BSESSION_ID%5D=your%20sessionid%20here&env%5BMODE%5D=private&env=%5BAUTO_READ%5D%3Dfalse&env%5BAUTO_READ_STATUS%5D=true"><img src="https://img.shields.io/badge/DEPLOY%20NOW-black" alt="Koyeb Tutorial" width="150"></a>
</details>

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

**(E) RAINHOST DEPLOYMENT**
<details>
<summary>CLICK FOR MORE</summary>
<a href="https://dash.rainxzet.com"><img src="https://img.shields.io/badge/RAINHOST%20SIGNUP-green" alt="Rainhost" width="150"></a>
<a href="https://github.com/mouricedevs/gifted/archive/refs/heads/main.zip"><img src="https://img.shields.io/badge/DOWNLOAD%20FILES-yellow" alt="Rainhost Files" width="150"></a>
<a href="https://youtu.be/8YpaGQQN_x4"><img src="https://img.shields.io/badge/WATCH%20TUTORIAL-white" alt="Rainhost Tutorial" width="150"></a>
</details>

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

**(F) SCALINGO DEPLOYMENT**
<details>
<summary>CLICK FOR MORE</summary>
<a href="https://scalingo.com/"><img src="https://img.shields.io/badge/SIGNUP%20&%20DEPLOY-gold" alt="Scalingo Deploy" width="150"></a>
</details

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>


### 𝟒. 𝐔𝐏𝐃𝐀𝐓𝐄𝐒 

<details>
<summary>𝗖𝗟𝗜𝗖𝗞 𝗛𝗘𝗥𝗘</summary>
  
- **[CONTACT SUPPORT](https://t.me/mouricedevs) For More Info**
- **Join [WHATSAPP CHANNEL](https://whatsapp.com/channel/0029VaYauR9ISTkHTj4xvi1l) for Daily Updates.**
- **Check out my [TELEGRAM BOT MD](https://web.giftedtechnexus.co.ke/bots/tg-bot) Project.**
</details>

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

### 𝟓. 𝐑𝐄𝐏𝐎 𝐒𝐓𝐀𝐑 𝐇𝐈𝐒𝐓𝐎𝐑𝐘 

[![Gifted-Md](https://api.star-history.com/svg?repos=mouricedevs/gifted&type=Timeline)](#)

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
