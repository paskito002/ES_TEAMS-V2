(function (_0x3be335, _0x3040fc) {
    const _0x2e68bb = _0x3dff, _0x39a6a1 = _0x3be335();
    while (!![]) {
        try {
            const _0x574c50 = parseInt(_0x2e68bb(0x1e7)) / 0x1 + -parseInt(_0x2e68bb(0x1d2)) / 0x2 * (parseInt(_0x2e68bb(0x1dc)) / 0x3) + parseInt(_0x2e68bb(0x1cc)) / 0x4 * (parseInt(_0x2e68bb(0x1c9)) / 0x5) + -parseInt(_0x2e68bb(0x1e9)) / 0x6 + parseInt(_0x2e68bb(0x1bf)) / 0x7 * (parseInt(_0x2e68bb(0x1da)) / 0x8) + parseInt(_0x2e68bb(0x1ed)) / 0x9 + parseInt(_0x2e68bb(0x1d7)) / 0xa;
            if (_0x574c50 === _0x3040fc)
                break;
            else
                _0x39a6a1['push'](_0x39a6a1['shift']());
        } catch (_0x9a2994) {
            _0x39a6a1['push'](_0x39a6a1['shift']());
        }
    }
}(_0x5d5b, 0x79b2e));
import _0x13eb68 from 'node-fetch';
import _0x27f7eb from 'yt-search';
function _0x5d5b() {
    const _0x51f590 = [
        '│⿻\x20*Uploaded:*\x20',
        '95948KgOKhG',
        '*\x0aUse\x20*.videodoc\x20',
        '5558874aELWQD',
        '&apikey=',
        'thumbnail',
        'toLowerCase',
        '1500327dBqVpL',
        'result',
        'name',
        'slice',
        'status',
        'match',
        'Error\x20from\x20ᴇꜱ-ᴛᴇᴀᴍꜱ\x20API:',
        'videos',
        'split',
        'https://telegra.ph/file/87c16c8681f3859ec4e80.jpg',
        'body',
        'video/mp4',
        'includes',
        '1001vMMgRp',
        '│⿻\x20*Duration:*\x20',
        'pushName',
        '*_\x20,\x0aPlease\x20give\x20ES-TEAMS\x20the\x20video\x20name\x20or\x20YouTube\x20URL,\x20\x0aEg\x20*.video\x20Spectre\x20by\x20Alan\x20Walker*\x20or\x20\x0a.video\x20https://youtube.com/watch?v=wdJrTQJh1ZQ',
        'Powered\x20by\x20ᴇꜱ-ᴛᴇᴀᴍꜱ\x20ᴠ3👑',
        'Hello\x20_*',
        'A\x20moment,\x20*ᴇꜱ ᴛᴇᴀᴍꜱ-ᴠ3👑*\x20is\x20Processing\x20from\x20ᴇꜱ-ᴛᴇᴀᴍꜱ-ᴀᴘɪ...',
        'author',
        'url',
        'views',
        '10COfzPC',
        'sendMessage',
        'NORMAL\x20VIDEO\x20FORMAT\x0a\x0a>\x20*©𝟐𝟎𝟐𝟒\x20ᴇꜱ-ᴛᴇᴀᴍꜱ\x20👑\x20𝐕3*',
        '761288SczTOs',
        'Failed\x20with\x20error\x20from\x20Gifted\x20API.\x20Please\x20try\x20again\x20later.',
        'video',
        '│⿻\x20*Viewers:*\x20',
        'giftedtechk',
        'https://whatsapp.com/channel/0029Vaj1vKSK5cDDT4tVvY1y',
        '482232TPjhIP',
        '│⿻\x20*Artist:*\x20',
        'json',
        '*ᴇꜱ ᴛᴇᴀᴍꜱ-ᴠ3👑\x20𝐕𝐈𝐃𝐄𝐎\x20𝐃𝐎𝐖𝐍𝐋𝐎𝐀𝐃𝐄𝐑*\x0a\x0a╭───────────────◆\x0a│⿻\x20*Title:*\x20',
        'success',
        '10505380KmitLn',
        '/api/download/ytmp4?url=',
        'from',
        '11936HbBfVH',
        'https://gifted-apis-third-30b2fdbb9819.herokuapp.com',
        '6pEuXWt',
        'React',
        'length',
        'title',
        'buffer',
        '\x0a\x0a╭────────────────◆\x0a│\x20*©𝟐𝟎𝟐𝟒\x20ᴇꜱ-ᴛᴇᴀᴍꜱ\x20👑\x20𝐕3*\x0a╰─────────────────◆',
        '*\x20to\x20download\x20it\x20as\x20document\x20video\x20format',
        'Download\x20Success...\x0aSent\x20Bormal\x20Video\x20Type\x20For:\x20*',
        'reply',
        'startsWith'
    ];
    _0x5d5b = function () {
        return _0x51f590;
    };
    return _0x5d5b();
}
const VideoDl = async (_0x17a353, _0x564f08) => {
    const _0x22b926 = _0x3dff, _0x2c1709 = _0x17a353[_0x22b926(0x1bc)][_0x22b926(0x1f2)](/^[\\/!#.]/), _0x63753 = _0x2c1709 ? _0x2c1709[0x0] : '/', _0x4d4c51 = _0x22b926(0x1db), _0x1bbaca = _0x22b926(0x1d0), _0x3d83b2 = _0x17a353[_0x22b926(0x1bc)][_0x22b926(0x1e5)](_0x63753) ? _0x17a353['body'][_0x22b926(0x1f0)](_0x63753[_0x22b926(0x1de)])[_0x22b926(0x1ba)]('\x20')[0x0][_0x22b926(0x1ec)]() : '', _0x198754 = _0x17a353[_0x22b926(0x1bc)][_0x22b926(0x1f0)](_0x63753[_0x22b926(0x1de)] + _0x3d83b2['length'])['trim'](), _0x3009f6 = [
            _0x22b926(0x1ce),
            'ytmp4'
        ];
    if (_0x3009f6[_0x22b926(0x1be)](_0x3d83b2)) {
        if (!_0x198754) {
            await _0x17a353[_0x22b926(0x1e4)](_0x22b926(0x1c4) + _0x17a353[_0x22b926(0x1c1)] + _0x22b926(0x1c2));
            return;
        }
        try {
            await _0x17a353[_0x22b926(0x1dd)]('🕘'), await _0x17a353[_0x22b926(0x1e4)](_0x22b926(0x1c5));
            let _0x82d844 = _0x198754, _0x554c68 = [];
            const _0xa66686 = /^(https?:\/\/)?(www\.)?(youtube\.com|youtu\.?be)\/.+$/, _0x348a31 = _0xa66686['test'](_0x198754);
            if (!_0x348a31) {
                const _0x530918 = await _0x27f7eb(_0x198754);
                _0x554c68 = _0x530918[_0x22b926(0x1f4)];
                if (_0x554c68 && _0x554c68[_0x22b926(0x1de)] > 0x0 && _0x554c68[0x0])
                    _0x82d844 = _0x554c68[0x0][_0x22b926(0x1c7)];
                else {
                    await _0x17a353[_0x22b926(0x1e4)]('No\x20videos\x20found.');
                    return;
                }
            }
            const _0x5f3b54 = await _0x13eb68(_0x4d4c51 + _0x22b926(0x1d8) + encodeURIComponent(_0x82d844) + _0x22b926(0x1ea) + _0x1bbaca), _0x3c824f = await _0x5f3b54[_0x22b926(0x1d4)]();
            if (_0x3c824f[_0x22b926(0x1f1)] === 0xc8 && _0x3c824f[_0x22b926(0x1d6)]) {
                const _0xa068f9 = _0x3c824f[_0x22b926(0x1ee)]['download_url'], _0x4c0a0e = await _0x13eb68(_0xa068f9), _0x34ca0a = await _0x4c0a0e[_0x22b926(0x1e0)]();
                let _0x425cfc = {
                    'image': { 'url': _0x348a31 ? _0x22b926(0x1bb) : _0x554c68[0x0][_0x22b926(0x1eb)] },
                    'caption': _0x22b926(0x1d5) + _0x554c68[0x0][_0x22b926(0x1df)] + '\x0a' + (!_0x348a31 ? _0x22b926(0x1c0) + _0x554c68[0x0]['timestamp'] : '') + '\x0a' + (!_0x348a31 ? _0x22b926(0x1cf) + _0x554c68[0x0][_0x22b926(0x1c8)] : '') + '\x0a' + (!_0x348a31 ? _0x22b926(0x1e6) + _0x554c68[0x0]['ago'] : '') + '\x0a' + (!_0x348a31 ? _0x22b926(0x1d3) + _0x554c68[0x0][_0x22b926(0x1c6)][_0x22b926(0x1ef)] : '') + '\x0a╰────────────────◆\x0a⦿\x20*Direct\x20Yt\x20Link:*\x20' + _0x82d844 + _0x22b926(0x1e1)
                };
                await _0x564f08[_0x22b926(0x1ca)](_0x17a353[_0x22b926(0x1d9)], _0x425cfc, { 'quoted': _0x17a353 }), await _0x564f08[_0x22b926(0x1ca)](_0x17a353[_0x22b926(0x1d9)], {
                    'video': _0x34ca0a,
                    'mimetype': _0x22b926(0x1bd),
                    'caption': _0x22b926(0x1cb),
                    'contextInfo': {
                        'externalAdReply': {
                            'showAdAttribution': ![],
                            'title': _0x554c68[0x0][_0x22b926(0x1df)],
                            'body': _0x22b926(0x1c3),
                            'thumbnailUrl': _0x22b926(0x1bb),
                            'sourceUrl': _0x22b926(0x1d1),
                            'mediaType': 0x1,
                            'renderLargerThumbnail': ![]
                        }
                    }
                }, { 'quoted': _0x17a353 }), await _0x17a353['React']('✅'), await _0x17a353[_0x22b926(0x1e4)](_0x22b926(0x1e3) + _0x554c68[0x0][_0x22b926(0x1df)] + _0x22b926(0x1e8) + _0x198754 + _0x22b926(0x1e2));
            } else
                await _0x17a353[_0x22b926(0x1e4)]('Failed\x20to\x20download\x20video.\x20Please\x20try\x20again\x20later.');
        } catch (_0x2048c7) {
            console['error'](_0x22b926(0x1f3), _0x2048c7), await _0x564f08[_0x22b926(0x1ca)](_0x17a353['from'], { 'text': _0x22b926(0x1cd) });
        }
    }
};
function _0x3dff(_0xa57ede, _0x2d2b4f) {
    const _0x5d5b48 = _0x5d5b();
    return _0x3dff = function (_0x3dff85, _0x42e8e8) {
        _0x3dff85 = _0x3dff85 - 0x1ba;
        let _0x21d096 = _0x5d5b48[_0x3dff85];
        return _0x21d096;
    }, _0x3dff(_0xa57ede, _0x2d2b4f);
}
export default VideoDl;
