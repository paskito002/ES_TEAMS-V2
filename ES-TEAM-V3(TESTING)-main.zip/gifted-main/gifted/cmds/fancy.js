(function (_0x5cbc35, _0x59a75e) {
    const _0x3f112f = _0x37e4, _0x521834 = _0x5cbc35();
    while (!![]) {
        try {
            const _0x15c843 = parseInt(_0x3f112f(0x105)) / 0x1 * (-parseInt(_0x3f112f(0x101)) / 0x2) + parseInt(_0x3f112f(0x120)) / 0x3 * (-parseInt(_0x3f112f(0x11b)) / 0x4) + parseInt(_0x3f112f(0x10d)) / 0x5 * (parseInt(_0x3f112f(0x104)) / 0x6) + -parseInt(_0x3f112f(0x11c)) / 0x7 * (-parseInt(_0x3f112f(0x115)) / 0x8) + parseInt(_0x3f112f(0x10b)) / 0x9 + -parseInt(_0x3f112f(0xfc)) / 0xa + -parseInt(_0x3f112f(0x113)) / 0xb * (-parseInt(_0x3f112f(0x11a)) / 0xc);
            if (_0x15c843 === _0x59a75e)
                break;
            else
                _0x521834['push'](_0x521834['shift']());
        } catch (_0x5e1955) {
            _0x521834['push'](_0x521834['shift']());
        }
    }
}(_0x237c, 0xc3d75));
import _0x267de1 from 'axios';
function _0x237c() {
    const _0x26b574 = [
        '260XTzKPC',
        'body',
        'from',
        'Fancy\x20Text\x20Styles:\x0a\x0a',
        '_,*\x0a\x20ᴇꜱ-ᴛᴇᴀᴍꜱ\x20Fancy\x20Text\x20Converter\x20Here.\x0a\x20Please\x20use\x20.fancy\x20*_your_text_*\x20or\x20.fancy5\x20*_your_text_*\x20to\x20get\x20a\x20specific\x20style.',
        'Error\x20getting\x20response\x20from\x20Gifted\x20API.',
        '18233171BTtFGs',
        'includes',
        '16JbrJgP',
        'slice',
        'reply',
        'Hello\x20*_',
        'data',
        '12ZhdREa',
        '168rSyLqp',
        '1741369qSxlfI',
        'get',
        'trim',
        'React',
        '13356cLrIdr',
        'forEach',
        'Fancy\x20Text\x20Styles:',
        'length',
        ':\x0a\x0a',
        '1272250rqOngp',
        'split',
        'sendMessage',
        'Error\x20getting\x20ᴇꜱ-ᴛᴇᴀᴍꜱ\x20API\x20response:',
        'error',
        '3041002TpllXr',
        'fancy',
        'message',
        '49422GUhAwH',
        '1Neypkv',
        'toLowerCase',
        'pushName',
        'No\x20valid\x20fancy\x20text\x20styles\x20were\x20generated.',
        'fancytext',
        'match',
        '481104KgQiHk',
        'result'
    ];
    _0x237c = function () {
        return _0x26b574;
    };
    return _0x237c();
}
const fancyText = async (_0x42e91f, _0x4b8728) => {
    const _0x3aaa01 = _0x37e4, _0x4338d9 = _0x42e91f[_0x3aaa01(0x10e)][_0x3aaa01(0x10a)](/^[\\/!#.]/), _0x2c9263 = _0x4338d9 ? _0x4338d9[0x0] : '/', _0x2c1ce6 = _0x42e91f[_0x3aaa01(0x10e)]['startsWith'](_0x2c9263) ? _0x42e91f[_0x3aaa01(0x10e)]['slice'](_0x2c9263['length'])[_0x3aaa01(0xfd)]('\x20')[0x0][_0x3aaa01(0x106)]() : '', _0x1830d2 = _0x42e91f[_0x3aaa01(0x10e)][_0x3aaa01(0x116)](_0x2c9263[_0x3aaa01(0xfa)] + _0x2c1ce6[_0x3aaa01(0xfa)])[_0x3aaa01(0x11e)](), _0x2e3634 = [
            _0x3aaa01(0x102),
            _0x3aaa01(0x109)
        ];
    if (_0x2e3634[_0x3aaa01(0x114)](_0x2c1ce6[_0x3aaa01(0xfd)](/\d+/)[0x0])) {
        const _0x124944 = _0x2c1ce6[_0x3aaa01(0x10a)](/\d+/), _0xd926b7 = _0x124944 ? parseInt(_0x124944[0x0], 0xa) : null;
        if (!_0x1830d2) {
            await _0x42e91f[_0x3aaa01(0x117)](_0x3aaa01(0x118) + _0x42e91f[_0x3aaa01(0x107)] + _0x3aaa01(0x111));
            return;
        }
        try {
            await _0x42e91f[_0x3aaa01(0x11f)]('🕘'), await _0x42e91f[_0x3aaa01(0x117)]('A\x20moment,\x20*ᴇꜱ-ᴛᴇᴀᴍꜱ*\x20is\x20Generating\x20Your\x20Fancy\x20Text\x20Styles\x20Request...');
            const _0x4d46e8 = 'https://api-smd.onrender.com/api/styletext?url=' + encodeURIComponent(_0x1830d2), _0x16881a = await _0x267de1[_0x3aaa01(0x11d)](_0x4d46e8), _0x1db0c5 = _0x16881a[_0x3aaa01(0x119)];
            if (_0x1db0c5 && _0x1db0c5[_0x3aaa01(0x10c)]) {
                const _0x341b7f = _0x1db0c5['result'];
                if (_0xd926b7 !== null) {
                    if (_0xd926b7 > 0x0 && _0xd926b7 <= _0x341b7f[_0x3aaa01(0xfa)]) {
                        const _0x2dd618 = _0x341b7f[_0xd926b7 - 0x1][_0x3aaa01(0x10c)];
                        await _0x4b8728[_0x3aaa01(0xfe)](_0x42e91f['from'], { 'text': 'Fancy\x20Text\x20Style\x20' + _0xd926b7 + _0x3aaa01(0xfb) + _0x2dd618 }, { 'quoted': _0x42e91f });
                    } else
                        await _0x42e91f[_0x3aaa01(0x117)]('Invalid\x20style\x20number.\x20Please\x20choose\x20a\x20number\x20between\x201\x20and\x20' + _0x341b7f[_0x3aaa01(0xfa)] + '.');
                } else {
                    let _0x5a2e6c = _0x3aaa01(0x110);
                    _0x341b7f[_0x3aaa01(0x121)]((_0x2766a0, _0x305689) => {
                        const _0x894caa = _0x3aaa01;
                        _0x2766a0[_0x894caa(0x10c)][_0x894caa(0x11e)]() && (_0x5a2e6c += _0x305689 + 0x1 + '.\x20' + _0x2766a0['result'] + '\x0a');
                    }), _0x5a2e6c[_0x3aaa01(0x11e)]() === _0x3aaa01(0x122) ? await _0x42e91f[_0x3aaa01(0x117)](_0x3aaa01(0x108)) : await _0x4b8728[_0x3aaa01(0xfe)](_0x42e91f[_0x3aaa01(0x10f)], { 'text': _0x5a2e6c[_0x3aaa01(0x11e)]() }, { 'quoted': _0x42e91f });
                }
                await _0x42e91f['React']('✅');
            } else
                throw new Error('Invalid\x20response\x20from\x20ᴇꜱ-ᴛᴇᴀᴍꜱ\x20API.');
        } catch (_0x42b5df) {
            console[_0x3aaa01(0x100)](_0x3aaa01(0xff), _0x42b5df[_0x3aaa01(0x103)]), await _0x42e91f[_0x3aaa01(0x117)](_0x3aaa01(0x112)), await _0x42e91f[_0x3aaa01(0x11f)]('❌');
        }
    }
};
function _0x37e4(_0x31b023, _0x40d2df) {
    const _0x237c3d = _0x237c();
    return _0x37e4 = function (_0x37e45c, _0x2b7f54) {
        _0x37e45c = _0x37e45c - 0xfa;
        let _0x4061ea = _0x237c3d[_0x37e45c];
        return _0x4061ea;
    }, _0x37e4(_0x31b023, _0x40d2df);
}
export default fancyText;
