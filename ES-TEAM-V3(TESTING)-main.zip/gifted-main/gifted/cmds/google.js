(function (_0x59965e, _0x10ad9a) {
    const _0x3c674b = _0x2169, _0x3526d3 = _0x59965e();
    while (!![]) {
        try {
            const _0x4f36b9 = -parseInt(_0x3c674b(0x75)) / 0x1 * (-parseInt(_0x3c674b(0x81)) / 0x2) + parseInt(_0x3c674b(0x8a)) / 0x3 * (-parseInt(_0x3c674b(0x85)) / 0x4) + parseInt(_0x3c674b(0x7c)) / 0x5 * (-parseInt(_0x3c674b(0x7a)) / 0x6) + parseInt(_0x3c674b(0x82)) / 0x7 + parseInt(_0x3c674b(0x83)) / 0x8 * (-parseInt(_0x3c674b(0x89)) / 0x9) + parseInt(_0x3c674b(0x84)) / 0xa * (parseInt(_0x3c674b(0x7b)) / 0xb) + -parseInt(_0x3c674b(0x87)) / 0xc * (-parseInt(_0x3c674b(0x76)) / 0xd);
            if (_0x4f36b9 === _0x10ad9a)
                break;
            else
                _0x3526d3['push'](_0x3526d3['shift']());
        } catch (_0x245883) {
            _0x3526d3['push'](_0x3526d3['shift']());
        }
    }
}(_0x468d, 0x8e17d));
import _0x505f77 from 'node-fetch';
import _0x1879f6 from 'google-it';
const GoogleSearch = async (_0x46a5fa, _0xf4f0a3) => {
    const _0x1d0934 = _0x2169, _0x146dcc = _0x46a5fa[_0x1d0934(0x97)]['match'](/^[\\/!#.]/), _0x4a95f8 = _0x146dcc ? _0x146dcc[0x0] : '/', _0x2558e3 = _0x46a5fa[_0x1d0934(0x97)][_0x1d0934(0x7e)](_0x4a95f8) ? _0x46a5fa['body'][_0x1d0934(0x8e)](_0x4a95f8['length'])['split']('\x20')[0x0][_0x1d0934(0x96)]() : '', _0x1f2d44 = _0x46a5fa[_0x1d0934(0x97)]['slice'](_0x4a95f8[_0x1d0934(0x90)] + _0x2558e3[_0x1d0934(0x90)])['trim'](), _0x4a19e9 = [
            _0x1d0934(0x88),
            _0x1d0934(0x93)
        ];
    if (_0x4a19e9['includes'](_0x2558e3))
        try {
            if (!_0x1f2d44)
                return _0x46a5fa['reply'](_0x1d0934(0x99) + _0x46a5fa[_0x1d0934(0x98)] + _0x1d0934(0x7f));
            await _0x46a5fa[_0x1d0934(0x80)](_0x1d0934(0x91));
            const _0x48def9 = await _0x1879f6({ 'query': _0x1f2d44 });
            let _0x13b19c = _0x1d0934(0x74) + _0x1f2d44 + _0x1d0934(0x95);
            for (let _0xb34e36 of _0x48def9) {
                _0x13b19c += _0x1d0934(0x8f) + _0xb34e36[_0x1d0934(0x79)] + '\x0a', _0x13b19c += _0x1d0934(0x94) + _0xb34e36[_0x1d0934(0x8c)] + '\x0a', _0x13b19c += _0x1d0934(0x86) + _0xb34e36[_0x1d0934(0x92)] + _0x1d0934(0x78);
            }
            _0x46a5fa[_0x1d0934(0x80)](_0x13b19c);
        } catch (_0x34c9d9) {
            console[_0x1d0934(0x8b)](_0x1d0934(0x7d), _0x34c9d9), await _0xf4f0a3[_0x1d0934(0x8d)](_0x46a5fa[_0x1d0934(0x77)], { 'text': 'Error\x20from\x20GiftedAPi.\x20Please\x20try\x20again\x20later.' }, { 'quoted': _0x46a5fa });
        }
};
function _0x2169(_0x4ff484, _0x285d95) {
    const _0x468d19 = _0x468d();
    return _0x2169 = function (_0x216931, _0x167f0e) {
        _0x216931 = _0x216931 - 0x74;
        let _0x5babe6 = _0x468d19[_0x216931];
        return _0x5babe6;
    }, _0x2169(_0x4ff484, _0x285d95);
}
export default GoogleSearch;
function _0x468d() {
    const _0x437806 = [
        'pushName',
        'Hello\x20_*',
        'Google\x20Search\x20Results\x20For\x20:\x20*',
        '437JMbJBe',
        '2783833bSrAjw',
        'from',
        '\x0a\x0a────────────────────────\x0a\x0a',
        'title',
        '868794tmCmcq',
        '447502hDLeQB',
        '10gryRPP',
        'Error\x20from\x20ᴇꜱ-ᴛᴇᴀᴍꜱ\x20APi:',
        'startsWith',
        '*_\x20Please\x20Insert\x20a\x20keyword\x20or\x20text\x20for\x20Google\x20Search!',
        'reply',
        '606tXAUUx',
        '3753036mGUGCm',
        '79992ZDHGBB',
        '30DznxJC',
        '1184AAQLhe',
        '➣\x20Link\x20:\x20',
        '60ELBzxw',
        'google',
        '837kxRAnT',
        '606AcmPox',
        'error',
        'snippet',
        'sendMessage',
        'slice',
        '➣\x20Title\x20:\x20',
        'length',
        'A\x20moment,\x20*ᴇꜱ ᴛᴇᴀᴍꜱ-ᴠ3👑*\x20is\x20Generating\x20Your\x20Google\x20Search\x20Request...',
        'link',
        'ggle',
        '➣\x20Description\x20:\x20',
        '*\x0a\x0a',
        'toLowerCase',
        'body'
    ];
    _0x468d = function () {
        return _0x437806;
    };
    return _0x468d();
}
