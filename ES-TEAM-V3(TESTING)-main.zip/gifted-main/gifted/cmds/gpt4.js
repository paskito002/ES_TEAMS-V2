(function (_0xb34cbd, _0x4492b5) {
    const _0x3df9d3 = _0x4a19, _0x55a06c = _0xb34cbd();
    while (!![]) {
        try {
            const _0x2086af = parseInt(_0x3df9d3(0x1c6)) / 0x1 * (parseInt(_0x3df9d3(0x1e2)) / 0x2) + -parseInt(_0x3df9d3(0x1e5)) / 0x3 + parseInt(_0x3df9d3(0x1f2)) / 0x4 + parseInt(_0x3df9d3(0x1e8)) / 0x5 * (parseInt(_0x3df9d3(0x1bf)) / 0x6) + -parseInt(_0x3df9d3(0x1e9)) / 0x7 + -parseInt(_0x3df9d3(0x1c5)) / 0x8 + -parseInt(_0x3df9d3(0x1d7)) / 0x9 * (-parseInt(_0x3df9d3(0x1cf)) / 0xa);
            if (_0x2086af === _0x4492b5)
                break;
            else
                _0x55a06c['push'](_0x55a06c['shift']());
        } catch (_0x127886) {
            _0x55a06c['push'](_0x55a06c['shift']());
        }
    }
}(_0x70b6, 0x40ad2));
import _0x31e708 from 'axios';
function _0x4a19(_0x590494, _0x1cd8bc) {
    const _0x70b633 = _0x70b6();
    return _0x4a19 = function (_0x4a1970, _0x5191ad) {
        _0x4a1970 = _0x4a1970 - 0x1bb;
        let _0x320340 = _0x70b633[_0x4a1970];
        return _0x320340;
    }, _0x4a19(_0x590494, _0x1cd8bc);
}
import _0x223d1e, { prepareWAMessageMedia } from 'gifted-baileys';
function _0x70b6() {
    const _0x376fd3 = [
        '2109107ZHZlNO',
        'giftedtechk',
        '&apikey=',
        '>\x20*©𝟐𝟎𝟐𝟒\x20ᴇꜱ\x20ᴛᴇᴀᴍꜱ\x20ᴠ3👑*',
        'cta_copy',
        'reply',
        'split',
        'React',
        'relayMessage',
        '1268956HvkYYe',
        'quick_reply',
        'Header',
        'get',
        'cta_url',
        'data',
        '1439466DoNJWi',
        'includes',
        'remoteJid',
        'InteractiveMessage',
        'key',
        'gpt4v2',
        '2503280FYZPPy',
        '3931uPOXey',
        'Message',
        'A\x20moment,\x20*ᴇꜱ ᴛᴇᴀᴍꜱ-ᴠ3👑*\x20is\x20Generating\x20Your\x20GPT4\x20Request...',
        'body',
        'gpt4ai',
        'push',
        'message',
        'Error\x20getting\x20response\x20from\x20GPT.',
        'slice',
        '10RBxXgU',
        'create',
        'chatgpt4v2',
        'https://whatsapp.com/channel/0029Vaj1vKSK5cDDT4tVvY1y',
        '.menu',
        'Invalid\x20response\x20from\x20the\x20GPT\x20API.',
        'result',
        'gpt',
        '2495313aIskJR',
        'https://api.giftedtechnexus.co.ke',
        'error',
        'pushName',
        'stringify',
        'ᴍᴀɪɴ\x20ᴍᴇɴᴜ',
        'NativeFlowMessage',
        'gpt4',
        'chatgpt4',
        '📋\x20ᴄᴏᴘʏ\x20ɢᴇɴᴇʀᴀᴛᴇᴅ\x20ᴄᴏᴅᴇ',
        '/api/ai/gpt4?q=',
        '140yFriWF',
        'startsWith',
        'match',
        '1411089csoUol',
        'chatgpt',
        'length',
        '10DKertM'
    ];
    _0x70b6 = function () {
        return _0x376fd3;
    };
    return _0x70b6();
}
const {generateWAMessageFromContent, proto} = _0x223d1e, gptResponse = async (_0x2173ac, _0x5e6280) => {
        const _0x3d187c = _0x4a19, _0x564607 = _0x2173ac[_0x3d187c(0x1c9)][_0x3d187c(0x1e4)](/^[\\/!#.]/), _0x31748c = _0x564607 ? _0x564607[0x0] : '/', _0x399d2b = _0x3d187c(0x1d8), _0x31ccba = _0x3d187c(0x1ea), _0x360d69 = _0x2173ac[_0x3d187c(0x1c9)][_0x3d187c(0x1e3)](_0x31748c) ? _0x2173ac[_0x3d187c(0x1c9)]['slice'](_0x31748c[_0x3d187c(0x1e7)])[_0x3d187c(0x1ef)]('\x20')[0x0]['toLowerCase']() : '', _0x265e9c = _0x2173ac[_0x3d187c(0x1c9)][_0x3d187c(0x1ce)](_0x31748c['length'] + _0x360d69[_0x3d187c(0x1e7)])['trim'](), _0x3fea45 = [
                _0x3d187c(0x1df),
                _0x3d187c(0x1d6),
                _0x3d187c(0x1e6),
                _0x3d187c(0x1c4),
                _0x3d187c(0x1d1),
                _0x3d187c(0x1de),
                _0x3d187c(0x1ca)
            ];
        if (_0x3fea45[_0x3d187c(0x1c0)](_0x360d69)) {
            if (!_0x265e9c)
                return _0x2173ac[_0x3d187c(0x1ee)]('Hello\x20*_' + _0x2173ac[_0x3d187c(0x1da)] + '_,*\x0a\x20I\x20am\x20Gifted\x20Premium\x20ChatGpt4.\x0a\x20Please\x20Ask\x20a\x20Question.');
            try {
                await _0x2173ac[_0x3d187c(0x1f0)]('🕘'), await _0x2173ac['reply'](_0x3d187c(0x1c8));
                const _0x149ced = _0x399d2b + _0x3d187c(0x1e1) + encodeURIComponent(_0x265e9c) + _0x3d187c(0x1eb) + _0x31ccba, _0x5084fe = await _0x31e708[_0x3d187c(0x1bc)](_0x149ced), _0x2c86cd = _0x5084fe[_0x3d187c(0x1be)];
                if (_0x2c86cd && _0x2c86cd[_0x3d187c(0x1d5)]) {
                    const _0xb33258 = _0x2c86cd[_0x3d187c(0x1d5)], _0x12b6f1 = '' + _0xb33258, _0x58289d = _0xb33258[_0x3d187c(0x1e4)](/```([\s\S]*?)```/);
                    let _0x508ded = [];
                    if (_0x58289d) {
                        const _0x4bfba9 = _0x58289d[0x1];
                        _0x508ded[_0x3d187c(0x1cb)]({
                            'name': _0x3d187c(0x1ed),
                            'buttonParamsJson': JSON[_0x3d187c(0x1db)]({
                                'display_text': _0x3d187c(0x1e0),
                                'id': 'copy_code',
                                'copy_code': _0x4bfba9
                            })
                        });
                    }
                    _0x508ded['push']({
                        'name': _0x3d187c(0x1ed),
                        'buttonParamsJson': JSON[_0x3d187c(0x1db)]({
                            'display_text': '📋\x20ᴄᴏᴘʏ\x20ᴡʜᴏʟᴇ\x20ᴛᴇxᴛ',
                            'id': 'copy_code',
                            'copy_code': _0x12b6f1
                        })
                    }, {
                        'name': _0x3d187c(0x1bd),
                        'buttonParamsJson': JSON['stringify']({
                            'display_text': 'sʜᴏᴡ\x20💜\x20ғᴏʀ\x20ɢɪғᴛᴇᴅ',
                            'url': _0x3d187c(0x1d2)
                        })
                    }, {
                        'name': _0x3d187c(0x1f3),
                        'buttonParamsJson': JSON[_0x3d187c(0x1db)]({
                            'display_text': _0x3d187c(0x1dc),
                            'id': _0x3d187c(0x1d3)
                        })
                    });
                    let _0x132ac2 = generateWAMessageFromContent(_0x2173ac['from'], {
                        'viewOnceMessage': {
                            'message': {
                                'messageContextInfo': {
                                    'deviceListMetadata': {},
                                    'deviceListMetadataVersion': 0x2
                                },
                                'interactiveMessage': proto['Message']['InteractiveMessage'][_0x3d187c(0x1d0)]({
                                    'body': proto['Message']['InteractiveMessage']['Body'][_0x3d187c(0x1d0)]({ 'text': _0xb33258 }),
                                    'footer': proto[_0x3d187c(0x1c7)]['InteractiveMessage']['Footer'][_0x3d187c(0x1d0)]({ 'text': _0x3d187c(0x1ec) }),
                                    'header': proto['Message'][_0x3d187c(0x1c2)][_0x3d187c(0x1bb)][_0x3d187c(0x1d0)]({
                                        'title': '',
                                        'subtitle': '',
                                        'hasMediaAttachment': ![]
                                    }),
                                    'nativeFlowMessage': proto[_0x3d187c(0x1c7)][_0x3d187c(0x1c2)][_0x3d187c(0x1dd)][_0x3d187c(0x1d0)]({ 'buttons': _0x508ded })
                                })
                            }
                        }
                    }, {});
                    await _0x5e6280[_0x3d187c(0x1f1)](_0x132ac2[_0x3d187c(0x1c3)][_0x3d187c(0x1c1)], _0x132ac2[_0x3d187c(0x1cc)], { 'messageId': _0x132ac2[_0x3d187c(0x1c3)]['id'] }), await _0x2173ac['React']('✅');
                } else
                    throw new Error(_0x3d187c(0x1d4));
            } catch (_0x44713a) {
                console[_0x3d187c(0x1d9)]('Error\x20getting\x20GPT\x20response:', _0x44713a[_0x3d187c(0x1cc)]), _0x2173ac['reply'](_0x3d187c(0x1cd)), await _0x2173ac[_0x3d187c(0x1f0)]('❌');
            }
        }
    };
export default gptResponse;
