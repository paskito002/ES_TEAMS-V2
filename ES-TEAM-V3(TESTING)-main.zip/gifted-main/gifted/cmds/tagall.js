(function (_0x2f1f1d, _0x289466) {
    const _0x4945ad = _0x2a18, _0x55d5f6 = _0x2f1f1d();
    while (!![]) {
        try {
            const _0xab99ac = -parseInt(_0x4945ad(0x77)) / 0x1 * (-parseInt(_0x4945ad(0x79)) / 0x2) + parseInt(_0x4945ad(0x87)) / 0x3 + -parseInt(_0x4945ad(0x7a)) / 0x4 + parseInt(_0x4945ad(0x7c)) / 0x5 + parseInt(_0x4945ad(0x94)) / 0x6 + parseInt(_0x4945ad(0x7d)) / 0x7 + parseInt(_0x4945ad(0x7b)) / 0x8 * (-parseInt(_0x4945ad(0x97)) / 0x9);
            if (_0xab99ac === _0x289466)
                break;
            else
                _0x55d5f6['push'](_0x55d5f6['shift']());
        } catch (_0x39ce1b) {
            _0x55d5f6['push'](_0x55d5f6['shift']());
        }
    }
}(_0x1736, 0x68006));
function _0x2a18(_0x1530db, _0x2dd37a) {
    const _0x17363d = _0x1736();
    return _0x2a18 = function (_0x2a18a7, _0x2a3bf7) {
        _0x2a18a7 = _0x2a18a7 - 0x76;
        let _0xc24d6e = _0x17363d[_0x2a18a7];
        return _0xc24d6e;
    }, _0x2a18(_0x1530db, _0x2dd37a);
}
const tagAll = async (_0xade7da, _0x4a5974) => {
    const _0xec1d26 = _0x2a18;
    try {
        const _0x3ae19f = await _0x4a5974[_0xec1d26(0x89)](_0x4a5974[_0xec1d26(0x93)]['id']), _0x57dfae = _0xade7da[_0xec1d26(0x90)][_0xec1d26(0x88)](/^[\\/!#.]/), _0x5a1b43 = _0x57dfae ? _0x57dfae[0x0] : '/', _0x401739 = _0xade7da[_0xec1d26(0x90)]['startsWith'](_0x5a1b43) ? _0xade7da[_0xec1d26(0x90)][_0xec1d26(0x8b)](_0x5a1b43[_0xec1d26(0x91)])[_0xec1d26(0x8d)]('\x20')[0x0][_0xec1d26(0x78)]() : '', _0x26f11b = [_0xec1d26(0x82)];
        if (!_0x26f11b[_0xec1d26(0x83)](_0x401739))
            return;
        const _0x49718a = await _0x4a5974[_0xec1d26(0x7f)](_0xade7da['from']), _0xa8196a = _0x49718a['participants'], _0x1184ed = _0xa8196a['find'](_0x5bc54c => _0x5bc54c['id'] === _0x3ae19f)?.[_0xec1d26(0x76)], _0x10271c = _0xa8196a[_0xec1d26(0x8a)](_0x3ff052 => _0x3ff052['id'] === _0xade7da[_0xec1d26(0x84)])?.[_0xec1d26(0x76)];
        if (!_0xade7da[_0xec1d26(0x96)])
            return _0xade7da['reply'](_0xec1d26(0x95));
        if (!_0x1184ed)
            return _0xade7da[_0xec1d26(0x86)](_0xec1d26(0x7e));
        if (!_0x10271c)
            return _0xade7da[_0xec1d26(0x86)](_0xec1d26(0x8c));
        let _0xa419a1 = _0xec1d26(0x98) + (_0xade7da['body'][_0xec1d26(0x8b)](_0x5a1b43[_0xec1d26(0x91)] + _0x401739[_0xec1d26(0x91)])[_0xec1d26(0x8e)]() || _0xec1d26(0x92)) + '\x0a\x0a';
        for (let _0x590563 of _0xa8196a) {
            _0xa419a1 += _0xec1d26(0x81) + _0x590563['id'][_0xec1d26(0x8d)]('@')[0x0] + '\x0a';
        }
        await _0x4a5974[_0xec1d26(0x8f)](_0xade7da[_0xec1d26(0x99)], {
            'text': _0xa419a1,
            'mentions': _0xa8196a[_0xec1d26(0x9a)](_0x4f1f9f => _0x4f1f9f['id'])
        }, { 'quoted': _0xade7da });
    } catch (_0x3db61c) {
        console['error'](_0xec1d26(0x85), _0x3db61c), await _0xade7da[_0xec1d26(0x86)](_0xec1d26(0x80));
    }
};
function _0x1736() {
    const _0x17decb = [
        '1638584hcextk',
        '3628705urdjNu',
        '68621ImLYKZ',
        '*📛\x20BOT\x20MUST\x20BE\x20AN\x20ADMIN\x20TO\x20USE\x20THIS\x20COMMAND*',
        'groupMetadata',
        'An\x20error\x20occurred\x20while\x20processing\x20the\x20command.',
        '❒\x20@',
        'tagall',
        'includes',
        'sender',
        'Error:',
        'reply',
        '225375LKRpZs',
        'match',
        'decodeJid',
        'find',
        'slice',
        '*📛\x20YOU\x20MUST\x20BE\x20AN\x20ADMIN\x20TO\x20USE\x20THIS\x20COMMAND*',
        'split',
        'trim',
        'sendMessage',
        'body',
        'length',
        'no\x20message',
        'user',
        '2060772uZydig',
        '*📛\x20THIS\x20COMMAND\x20CAN\x20ONLY\x20BE\x20USED\x20IN\x20GROUPS*',
        'isGroup',
        '63WGwNKi',
        '●\x20*Attention\x20Everyone*\x20●\x0a\x0a*Message:*\x20',
        'from',
        'map',
        'admin',
        '274501ycslxS',
        'toLowerCase',
        '6mENeGw',
        '471532RYOaCN'
    ];
    _0x1736 = function () {
        return _0x17decb;
    };
    return _0x1736();
}
export default tagAll;
