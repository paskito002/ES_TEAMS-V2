(function (_0x37a95f, _0xbef64b) {
    const _0x1c9589 = _0x43e3, _0x121ce4 = _0x37a95f();
    while (!![]) {
        try {
            const _0x28d3ed = -parseInt(_0x1c9589(0x96)) / 0x1 + parseInt(_0x1c9589(0x8e)) / 0x2 * (-parseInt(_0x1c9589(0x8f)) / 0x3) + parseInt(_0x1c9589(0x84)) / 0x4 + parseInt(_0x1c9589(0x7b)) / 0x5 * (-parseInt(_0x1c9589(0x81)) / 0x6) + -parseInt(_0x1c9589(0x95)) / 0x7 * (-parseInt(_0x1c9589(0x8a)) / 0x8) + -parseInt(_0x1c9589(0x8d)) / 0x9 + parseInt(_0x1c9589(0x83)) / 0xa * (parseInt(_0x1c9589(0x97)) / 0xb);
            if (_0x28d3ed === _0xbef64b)
                break;
            else
                _0x121ce4['push'](_0x121ce4['shift']());
        } catch (_0x51f40c) {
            _0x121ce4['push'](_0x121ce4['shift']());
        }
    }
}(_0x4594, 0xdac7a));
import _0x4b21cb from 'node-fetch';
function _0x43e3(_0x17a34b, _0x5752f2) {
    const _0x4594a8 = _0x4594();
    return _0x43e3 = function (_0x43e351, _0x432e2a) {
        _0x43e351 = _0x43e351 - 0x78;
        let _0x14952a = _0x4594a8[_0x43e351];
        return _0x14952a;
    }, _0x43e3(_0x17a34b, _0x5752f2);
}
const LoveNight = async (_0x5f18b0, _0x1a1100) => {
    const _0x1b03b9 = _0x43e3, _0x1a9e1a = _0x5f18b0[_0x1b03b9(0x9a)]['match'](/^[\\/!#.]/), _0x2f5b7c = _0x1a9e1a ? _0x1a9e1a[0x0] : '/', _0x11c9bd = _0x5f18b0[_0x1b03b9(0x9a)][_0x1b03b9(0x82)](_0x2f5b7c) ? _0x5f18b0[_0x1b03b9(0x9a)]['slice'](_0x2f5b7c[_0x1b03b9(0x8b)])[_0x1b03b9(0x78)]('\x20')[0x0][_0x1b03b9(0x9b)]() : '', _0x59f46e = [
            _0x1b03b9(0x7a),
            _0x1b03b9(0x7e),
            'lovenight',
            _0x1b03b9(0x7d),
            _0x1b03b9(0x99)
        ];
    if (_0x59f46e['includes'](_0x11c9bd))
        try {
            await _0x5f18b0[_0x1b03b9(0x93)]('🕘'), await _0x5f18b0[_0x1b03b9(0x79)](_0x1b03b9(0x85));
            const _0x3ff102 = _0x1b03b9(0x94), _0x2cd989 = await _0x4b21cb(_0x1b03b9(0x8c) + _0x3ff102);
            if (!_0x2cd989['ok'])
                throw new Error(await _0x2cd989[_0x1b03b9(0x80)]());
            const _0x3cefe8 = await _0x2cd989[_0x1b03b9(0x98)]();
            if (!_0x3cefe8[_0x1b03b9(0x90)])
                throw new Error(_0x1b03b9(0x91));
            const _0x5e3eab = _0x3cefe8[_0x1b03b9(0x90)];
            await _0x1a1100[_0x1b03b9(0x7f)](_0x5f18b0['from'], {
                'text': _0x5e3eab,
                'mentions': [_0x5f18b0[_0x1b03b9(0x86)]]
            }, { 'quoted': _0x5f18b0 }), await _0x5f18b0['react']('✅');
        } catch (_0x280af8) {
            console[_0x1b03b9(0x92)](_0x1b03b9(0x89), _0x280af8[_0x1b03b9(0x87)]), console[_0x1b03b9(0x92)](_0x1b03b9(0x88), _0x280af8), await _0x1a1100[_0x1b03b9(0x7f)](_0x5f18b0[_0x1b03b9(0x7c)], { 'text': 'Failed\x20to\x20retrieve\x20message.' });
        }
};
export default LoveNight;
function _0x4594() {
    const _0x3319a4 = [
        'reply',
        'night',
        '1225lTzUpv',
        'from',
        'night-love',
        'nightlove',
        'sendMessage',
        'text',
        '26790OCiWaO',
        'startsWith',
        '10XWDRBL',
        '90760oBEjwL',
        'A\x20moment,\x20*ᴇꜱ-ᴛᴇᴀᴍꜱ*\x20is\x20generating\x20your\x20LoveNight\x20message...',
        'sender',
        'message',
        'Error\x20details:',
        'Error\x20fetching\x20LoveNight\x20message:',
        '8WsbcJm',
        'length',
        'https://shizoapi.onrender.com/api/texts/lovenight?apikey=',
        '13872051onXAFP',
        '82bSrXqg',
        '18888zbKWpu',
        'result',
        'Invalid\x20response\x20format',
        'error',
        'react',
        'shizo',
        '12283411SlqqHu',
        '1234656dxCasJ',
        '35713865hUFqUk',
        'json',
        'love-night',
        'body',
        'toLowerCase',
        'split'
    ];
    _0x4594 = function () {
        return _0x3319a4;
    };
    return _0x4594();
}
