(function (_0x1b7cdb, _0xe7f4b0) {
    const _0x3c5e7e = _0x5cef, _0x248b02 = _0x1b7cdb();
    while (!![]) {
        try {
            const _0x58fee2 = parseInt(_0x3c5e7e(0xca)) / 0x1 * (-parseInt(_0x3c5e7e(0x9d)) / 0x2) + -parseInt(_0x3c5e7e(0xc3)) / 0x3 * (parseInt(_0x3c5e7e(0xc1)) / 0x4) + parseInt(_0x3c5e7e(0xbf)) / 0x5 + -parseInt(_0x3c5e7e(0xd1)) / 0x6 + parseInt(_0x3c5e7e(0xa5)) / 0x7 * (-parseInt(_0x3c5e7e(0xa2)) / 0x8) + -parseInt(_0x3c5e7e(0xc8)) / 0x9 * (-parseInt(_0x3c5e7e(0xae)) / 0xa) + parseInt(_0x3c5e7e(0xa8)) / 0xb * (parseInt(_0x3c5e7e(0xd3)) / 0xc);
            if (_0x58fee2 === _0xe7f4b0)
                break;
            else
                _0x248b02['push'](_0x248b02['shift']());
        } catch (_0x2d752d) {
            _0x248b02['push'](_0x248b02['shift']());
        }
    }
}(_0x4c49, 0x98c72));
function _0x4c49() {
    const _0x29502c = [
        'A\x20moment,\x20*ᴇꜱ-ᴛᴇᴀᴍꜱd*\x20is\x20Generating\x20Your\x20Pairing\x20Code...',
        '98XNZuvH',
        'trim',
        'https://whatsapp.com/channel/0029Vaj1vKSK5cDDT4tVvY1y',
        '3817WSkikG',
        'body',
        'pushName',
        'sessionpair',
        '_,*\x0aPlease\x20Provide\x20Phone\x20Number\x20in\x20International\x20Format\x20Without\x20(+)\x20Sign\x0aEg\x20.pair\x20254711111111',
        'data',
        '10JDqZNb',
        'startsWith',
        'Dear\x20*_',
        '📋\x20ᴄᴏᴘʏ\x20ʏᴏᴜʀ\x20ᴄᴏᴅᴇ',
        'InteractiveMessage',
        'Message',
        'create',
        'push',
        'remoteJid',
        'slice',
        '_*,\x0aYour\x20ᴇꜱ ᴛᴇᴀᴍꜱ-ᴠ3👑\x20PairingCode\x20is:\x20*',
        'error',
        'Error\x20getting\x20ᴇꜱ-ᴛᴇᴀᴍꜱ\x20APi\x20response:',
        'ᴍᴀɪɴ\x20ᴍᴇɴᴜ',
        'session',
        'includes',
        'Invalid\x20response\x20from\x20Gifted\x20API.',
        '6122055KhJfdc',
        'message',
        '4233604sbQGgz',
        'match',
        '3cbOBPH',
        'split',
        'stringify',
        'toLowerCase',
        'from',
        '3560220vAPPeQ',
        'cta_copy',
        '1lvaDsY',
        'relayMessage',
        'linkphone',
        'Error\x20getting\x20response\x20from\x20Gifted\x20Api.',
        '>\x20*©𝟐𝟎𝟐𝟒\x20ᴇꜱ\x20ᴛᴇᴀᴍꜱ\x20ᴠ3👑*',
        'code',
        'paircode',
        '419868eekrej',
        'key',
        '44628VDydqh',
        'length',
        'sʜᴏᴡ\x20💜\x20ғᴏʀ\x20ᴇꜱ-ᴛᴇᴀᴍꜱ',
        'cta_url',
        'copy_code',
        'pair',
        'getsession',
        'Body',
        'quick_reply',
        'Footer',
        'Header',
        '712202XojYqk',
        'React',
        'reply',
        '📋\x20ᴄᴏᴘʏ\x20ᴘᴀɪʀɪɴɢ\x20ᴄᴏᴅᴇ',
        'Hello\x20*_',
        '457272PCSohq',
        'get'
    ];
    _0x4c49 = function () {
        return _0x29502c;
    };
    return _0x4c49();
}
import _0x31a011 from 'axios';
import _0x201062, { prepareWAMessageMedia } from 'gifted-baileys';
function _0x5cef(_0x54e01f, _0x5ac4b8) {
    const _0x4c49d8 = _0x4c49();
    return _0x5cef = function (_0x5cef6e, _0x5f8821) {
        _0x5cef6e = _0x5cef6e - 0x94;
        let _0xd127dc = _0x4c49d8[_0x5cef6e];
        return _0xd127dc;
    }, _0x5cef(_0x54e01f, _0x5ac4b8);
}
const {generateWAMessageFromContent, proto} = _0x201062, GetSess = async (_0x570582, _0x1bae92) => {
        const _0x3103ed = _0x5cef, _0x2e0a32 = _0x570582['body'][_0x3103ed(0xc2)](/^[\\/!#.]/), _0x52b191 = _0x2e0a32 ? _0x2e0a32[0x0] : '/', _0x5954ff = _0x570582['body'][_0x3103ed(0xaf)](_0x52b191) ? _0x570582['body'][_0x3103ed(0xb7)](_0x52b191[_0x3103ed(0xd4)])[_0x3103ed(0xc4)]('\x20')[0x0][_0x3103ed(0xc6)]() : '', _0x59fe92 = _0x570582[_0x3103ed(0xa9)][_0x3103ed(0xb7)](_0x52b191[_0x3103ed(0xd4)] + _0x5954ff[_0x3103ed(0xd4)])[_0x3103ed(0xa6)](), _0x36cb9d = [
                _0x3103ed(0x97),
                _0x3103ed(0xd0),
                'pairingcode',
                _0x3103ed(0xcc),
                _0x3103ed(0x98),
                _0x3103ed(0xbc),
                _0x3103ed(0xab)
            ];
        if (_0x36cb9d[_0x3103ed(0xbd)](_0x5954ff)) {
            if (!_0x59fe92)
                return _0x570582[_0x3103ed(0x9f)](_0x3103ed(0xa1) + _0x570582[_0x3103ed(0xaa)] + _0x3103ed(0xac));
            try {
                await _0x570582[_0x3103ed(0x9e)]('🕘'), await _0x570582[_0x3103ed(0x9f)](_0x3103ed(0xa4));
                const _0x1604c6 = 'https://gifted-main-pairing-21f51548de0c.herokuapp.com/pair?phone=' + encodeURIComponent(_0x59fe92), _0x3eb814 = await _0x31a011[_0x3103ed(0xa3)](_0x1604c6), _0x248705 = _0x3eb814[_0x3103ed(0xad)];
                if (_0x248705 && _0x248705[_0x3103ed(0xcf)]) {
                    const _0x1ada77 = _0x248705[_0x3103ed(0xcf)], _0x234b38 = _0x3103ed(0xb0) + _0x570582[_0x3103ed(0xaa)] + _0x3103ed(0xb8) + _0x1ada77 + '*\x0aUse\x20it\x20to\x20Link\x20Your\x20WhatsApp\x20Within\x201\x20Minute\x20Before\x20it\x20Expires\x0aThereafter,\x20Obtain\x20Your\x20Session\x20ID.\x0aHappy\x20Bot\x20Deployment!!!', _0x4bdbf8 = _0x234b38['match'](/```([\s\S]*?)```/);
                    let _0x186ef6 = [];
                    if (_0x4bdbf8) {
                        const _0x530f87 = _0x4bdbf8[0x1];
                        _0x186ef6[_0x3103ed(0xb5)]({
                            'name': _0x3103ed(0xc9),
                            'buttonParamsJson': JSON[_0x3103ed(0xc5)]({
                                'display_text': _0x3103ed(0xb1),
                                'id': _0x3103ed(0x96),
                                'copy_code': _0x1ada77
                            })
                        });
                    }
                    _0x186ef6[_0x3103ed(0xb5)]({
                        'name': _0x3103ed(0x9a),
                        'buttonParamsJson': JSON[_0x3103ed(0xc5)]({
                            'display_text': _0x3103ed(0xbb),
                            'id': '.menu'
                        })
                    }, {
                        'name': 'cta_copy',
                        'buttonParamsJson': JSON[_0x3103ed(0xc5)]({
                            'display_text': _0x3103ed(0xa0),
                            'id': _0x3103ed(0x96),
                            'copy_code': _0x1ada77
                        })
                    }, {
                        'name': _0x3103ed(0x95),
                        'buttonParamsJson': JSON[_0x3103ed(0xc5)]({
                            'display_text': _0x3103ed(0x94),
                            'url': _0x3103ed(0xa7)
                        })
                    });
                    let _0x20a753 = generateWAMessageFromContent(_0x570582[_0x3103ed(0xc7)], {
                        'viewOnceMessage': {
                            'message': {
                                'messageContextInfo': {
                                    'deviceListMetadata': {},
                                    'deviceListMetadataVersion': 0x2
                                },
                                'interactiveMessage': proto[_0x3103ed(0xb3)]['InteractiveMessage'][_0x3103ed(0xb4)]({
                                    'body': proto['Message'][_0x3103ed(0xb2)][_0x3103ed(0x99)][_0x3103ed(0xb4)]({ 'text': _0x234b38 }),
                                    'footer': proto[_0x3103ed(0xb3)][_0x3103ed(0xb2)][_0x3103ed(0x9b)][_0x3103ed(0xb4)]({ 'text': _0x3103ed(0xce) }),
                                    'header': proto['Message'][_0x3103ed(0xb2)][_0x3103ed(0x9c)][_0x3103ed(0xb4)]({
                                        'title': '',
                                        'subtitle': '',
                                        'hasMediaAttachment': ![]
                                    }),
                                    'nativeFlowMessage': proto[_0x3103ed(0xb3)][_0x3103ed(0xb2)]['NativeFlowMessage'][_0x3103ed(0xb4)]({ 'buttons': _0x186ef6 })
                                })
                            }
                        }
                    }, {});
                    await _0x1bae92[_0x3103ed(0xcb)](_0x20a753[_0x3103ed(0xd2)][_0x3103ed(0xb6)], _0x20a753[_0x3103ed(0xc0)], { 'messageId': _0x20a753[_0x3103ed(0xd2)]['id'] }), await _0x570582[_0x3103ed(0x9e)]('✅');
                } else
                    throw new Error(_0x3103ed(0xbe));
            } catch (_0xc08bd9) {
                console[_0x3103ed(0xb9)](_0x3103ed(0xba), _0xc08bd9[_0x3103ed(0xc0)]), _0x570582[_0x3103ed(0x9f)](_0x3103ed(0xcd)), await _0x570582[_0x3103ed(0x9e)]('❌');
            }
        }
    };
export default GetSess;
