const _0x241add = _0x4e5e;
(function (_0x5cfe73, _0x3d3e5f) {
    const _0x140cf5 = _0x4e5e, _0x7defc4 = _0x5cfe73();
    while (!![]) {
        try {
            const _0x429f2b = -parseInt(_0x140cf5(0x110)) / 0x1 + -parseInt(_0x140cf5(0x10e)) / 0x2 * (parseInt(_0x140cf5(0x122)) / 0x3) + parseInt(_0x140cf5(0x11c)) / 0x4 * (-parseInt(_0x140cf5(0x10f)) / 0x5) + -parseInt(_0x140cf5(0x10c)) / 0x6 + parseInt(_0x140cf5(0x11b)) / 0x7 * (-parseInt(_0x140cf5(0x112)) / 0x8) + parseInt(_0x140cf5(0x123)) / 0x9 * (parseInt(_0x140cf5(0x10b)) / 0xa) + -parseInt(_0x140cf5(0x10a)) / 0xb * (-parseInt(_0x140cf5(0x116)) / 0xc);
            if (_0x429f2b === _0x3d3e5f)
                break;
            else
                _0x7defc4['push'](_0x7defc4['shift']());
        } catch (_0x5ed53a) {
            _0x7defc4['push'](_0x7defc4['shift']());
        }
    }
}(_0x3977, 0xd753e));
import { createRequire } from 'module';
import _0x5dbb8e from 'path';
function _0x3977() {
    const _0x13b67c = [
        'mtype',
        '535317qqEocv',
        '10237806xSbkLx',
        'toLowerCase',
        'error',
        'imageMessage',
        'from',
        'quoted',
        'dirname',
        'length',
        'remini',
        '3251534zgtgyX',
        '10LccQqb',
        '3875652aIcigy',
        'reply',
        '4bvQIeC',
        '968115tAinWb',
        '1495420xtvxUo',
        'slice',
        '15832YUaCLP',
        'Error\x20processing\x20media:',
        '../gift.cjs',
        'enhance',
        '168aIakdx',
        'body',
        'pathname',
        'split',
        'url',
        '1911MevpLd',
        '28LAnfBB',
        'match',
        'sendMessage',
        '\x20Here\x20Is\x20Your\x20Enhanced\x20Image\x20By\x20𝐆𝐈𝐅𝐓𝐄𝐃-𝐌𝐃*',
        'download'
    ];
    _0x3977 = function () {
        return _0x13b67c;
    };
    return _0x3977();
}
const require = createRequire(import.meta[_0x241add(0x11a)]), __filename = new URL(import.meta[_0x241add(0x11a)])[_0x241add(0x118)], __dirname = _0x5dbb8e[_0x241add(0x129)](__filename), reminiPath = _0x5dbb8e['resolve'](__dirname, _0x241add(0x114)), {remini} = require(reminiPath), tourl = async (_0x460195, _0x2ea541) => {
        const _0x3e1e9d = _0x241add, _0x452915 = _0x460195[_0x3e1e9d(0x117)][_0x3e1e9d(0x11d)](/^[\\/!#.]/), _0x205784 = _0x452915 ? _0x452915[0x0] : '/', _0x156ff3 = _0x460195[_0x3e1e9d(0x117)]['startsWith'](_0x205784) ? _0x460195[_0x3e1e9d(0x117)][_0x3e1e9d(0x111)](_0x205784[_0x3e1e9d(0x108)])[_0x3e1e9d(0x119)]('\x20')[0x0][_0x3e1e9d(0x124)]() : '', _0x372e48 = [
                'hdr',
                'hd',
                _0x3e1e9d(0x109),
                _0x3e1e9d(0x115),
                'upscale'
            ];
        if (_0x372e48['includes'](_0x156ff3)) {
            if (!_0x460195[_0x3e1e9d(0x128)] || _0x460195[_0x3e1e9d(0x128)][_0x3e1e9d(0x121)] !== _0x3e1e9d(0x126))
                return _0x460195[_0x3e1e9d(0x10d)]('*Send/Reply\x20with\x20an\x20Image\x20to\x20Enhance\x20Your\x20Picture\x20Quality\x20' + (_0x205784 + _0x156ff3) + '*');
            const _0x5df4ab = await _0x460195[_0x3e1e9d(0x128)][_0x3e1e9d(0x120)]();
            try {
                let _0x415524 = await remini(_0x5df4ab, 'enhance');
                _0x2ea541[_0x3e1e9d(0x11e)](_0x460195[_0x3e1e9d(0x127)], {
                    'image': _0x415524,
                    'caption': '>\x20*Hey\x20' + _0x460195['pushName'] + _0x3e1e9d(0x11f)
                }, { 'quoted': _0x460195 });
            } catch (_0x5a5338) {
                console[_0x3e1e9d(0x125)](_0x3e1e9d(0x113), _0x5a5338), _0x460195[_0x3e1e9d(0x10d)]('Error\x20processing\x20media.');
            }
        }
    };
function _0x4e5e(_0xae6876, _0x3a5cd9) {
    const _0x397706 = _0x3977();
    return _0x4e5e = function (_0x4e5e0f, _0xa24222) {
        _0x4e5e0f = _0x4e5e0f - 0x108;
        let _0xf33091 = _0x397706[_0x4e5e0f];
        return _0xf33091;
    }, _0x4e5e(_0xae6876, _0x3a5cd9);
}
export default tourl;
