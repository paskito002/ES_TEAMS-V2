(function (_0x463d9d, _0x56a52a) {
    const _0x2143de = _0x1ae9, _0x378d42 = _0x463d9d();
    while (!![]) {
        try {
            const _0x36bd84 = parseInt(_0x2143de(0xd3)) / 0x1 + parseInt(_0x2143de(0xb8)) / 0x2 * (parseInt(_0x2143de(0xd1)) / 0x3) + -parseInt(_0x2143de(0xd2)) / 0x4 * (-parseInt(_0x2143de(0xe6)) / 0x5) + parseInt(_0x2143de(0xd5)) / 0x6 * (-parseInt(_0x2143de(0xe0)) / 0x7) + parseInt(_0x2143de(0xde)) / 0x8 + -parseInt(_0x2143de(0xc3)) / 0x9 + -parseInt(_0x2143de(0xd8)) / 0xa * (parseInt(_0x2143de(0xd7)) / 0xb);
            if (_0x36bd84 === _0x56a52a)
                break;
            else
                _0x378d42['push'](_0x378d42['shift']());
        } catch (_0x5570ae) {
            _0x378d42['push'](_0x378d42['shift']());
        }
    }
}(_0x5c13, 0xaeda0));
function _0x1ae9(_0x4e49b5, _0xa219db) {
    const _0x5c13c8 = _0x5c13();
    return _0x1ae9 = function (_0x1ae91c, _0x49fd9e) {
        _0x1ae91c = _0x1ae91c - 0xb7;
        let _0x371000 = _0x5c13c8[_0x1ae91c];
        return _0x371000;
    }, _0x1ae9(_0x4e49b5, _0xa219db);
}
function _0x5c13() {
    const _0x54d3d4 = [
        'Test\x20Successful,\x20Bot\x20is\x20Active...',
        '28wYQMfR',
        'giftedtechk',
        'toLowerCase',
        'Audio\x20not\x20found.',
        'slice',
        'OtileBrownft.Prezzo-Ndagukunda',
        '725isEDkY',
        'Error\x20generating\x20response:',
        '2RFEWEs',
        'split',
        'https://gifted-apis-third-30b2fdbb9819.herokuapp.com',
        'audio/mpeg',
        'React',
        'AlanWalker-OnMyWay(Clean-Lyrics)ft.SabrinaCarpenter&Farruko',
        'random',
        'url',
        'length',
        'error',
        'AlanWalker-Play(TiktokVersion)-SpeedUp',
        '2191545AURtxd',
        ',*_\x0a\x20*Gifted-Md*\x20is\x20Sending\x20a\x20Random\x20Test\x20Audio...',
        'AlanWalker-Play(Tiktok-EDM)',
        'floor',
        'match',
        'startsWith',
        'ᴇꜱ-ᴛᴇᴀᴍꜱ\x20ᴠ3👑\x20𝐈𝐒\x20𝐀𝐂𝐓𝐈𝐕𝐄',
        '/api/download/ytmp3?url=',
        'sender',
        'body',
        'reply',
        'includes',
        'AlanWalker-Spectre',
        'Error\x20processing\x20your\x20request.',
        '1683630UcdEll',
        '27092VjDvMF',
        '1084640KizrgM',
        'buffer',
        '368886omHdqH',
        '&apikey=',
        '11rHzaNc',
        '23703890UwwWbm',
        'status',
        'test',
        '💜ᴘᴏᴡᴇʀᴇᴅ\x20ʙʏ\x20ᴇꜱ\x20ᴛᴇᴀᴍꜱ💜',
        'videos',
        'pushName',
        '7584600aBYOcn'
    ];
    _0x5c13 = function () {
        return _0x54d3d4;
    };
    return _0x5c13();
}
import _0x3b5359 from 'node-fetch';
import _0x11a7b1 from 'yt-search';
const test = async (_0x419a78, _0x462427) => {
    const _0x3c1da2 = _0x1ae9;
    try {
        const _0x54c93f = _0x419a78['body'][_0x3c1da2(0xc7)](/^[\\/!#.]/), _0x9f4a1a = _0x54c93f ? _0x54c93f[0x0] : '/', _0x3b1286 = _0x3c1da2(0xba), _0x51063c = _0x3c1da2(0xe1), _0xad99c5 = _0x419a78['body'][_0x3c1da2(0xc8)](_0x9f4a1a) ? _0x419a78[_0x3c1da2(0xcc)][_0x3c1da2(0xe4)](_0x9f4a1a[_0x3c1da2(0xc0)])[_0x3c1da2(0xb9)]('\x20')[0x0][_0x3c1da2(0xe2)]() : '', _0x2475ed = [_0x3c1da2(0xda)];
        if (_0x2475ed[_0x3c1da2(0xce)](_0xad99c5)) {
            await _0x419a78[_0x3c1da2(0xbc)]('🕘'), await _0x419a78[_0x3c1da2(0xcd)]('Hello\x20_*' + _0x419a78[_0x3c1da2(0xdd)] + _0x3c1da2(0xc4));
            const _0x2c8b43 = [
                    _0x3c1da2(0xbd),
                    _0x3c1da2(0xcf),
                    _0x3c1da2(0xe5),
                    _0x3c1da2(0xc5),
                    'Ride+or+Die-Lexnour',
                    _0x3c1da2(0xc2)
                ], _0x461e7e = _0x2c8b43[Math[_0x3c1da2(0xc6)](Math[_0x3c1da2(0xbe)]() * _0x2c8b43[_0x3c1da2(0xc0)])], _0x493660 = await _0x11a7b1(_0x461e7e), _0x2fecee = _0x493660[_0x3c1da2(0xdc)][0x0];
            if (!_0x2fecee) {
                await _0x419a78[_0x3c1da2(0xcd)](_0x3c1da2(0xe3)), await _0x419a78[_0x3c1da2(0xbc)]('❌');
                return;
            }
            const _0x27d1a2 = _0x2fecee[_0x3c1da2(0xbf)], _0x45d591 = await _0x3b5359(_0x3b1286 + _0x3c1da2(0xca) + encodeURIComponent(_0x27d1a2) + _0x3c1da2(0xd6) + _0x51063c), _0x84ecbf = await _0x45d591['json']();
            if (_0x84ecbf[_0x3c1da2(0xd9)] === 0xc8 && _0x84ecbf['success']) {
                const _0x36d25b = _0x84ecbf['result']['download_url'], _0x3d7ae3 = await _0x3b5359(_0x36d25b), _0x145879 = await _0x3d7ae3[_0x3c1da2(0xd4)](), _0xaca259 = {
                        'audio': _0x145879,
                        'mimetype': _0x3c1da2(0xbb),
                        'ptt': !![],
                        'waveform': [
                            0x3e8,
                            0x0,
                            0x3e8,
                            0x0,
                            0x3e8,
                            0x0,
                            0x3e8
                        ],
                        'contextInfo': {
                            'mentionedJid': [_0x419a78[_0x3c1da2(0xcb)]],
                            'externalAdReply': {
                                'title': _0x3c1da2(0xc9),
                                'body': _0x3c1da2(0xdb),
                                'thumbnailUrl': 'https://telegra.ph/file/87c16c8681f3859ec4e80.jpg',
                                'sourceUrl': 'https://whatsapp.com/channel/0029Vaj1vKSK5cDDT4tVvY1y',
                                'mediaType': 0x5,
                                'renderLargerThumbnail': ![]
                            }
                        }
                    };
                await _0x462427['sendMessage'](_0x419a78['from'], _0xaca259, { 'quoted': _0x419a78 }), await _0x419a78['React']('✅'), await _0x419a78['reply'](_0x3c1da2(0xdf));
            } else
                await _0x419a78[_0x3c1da2(0xcd)]('Failed\x20to\x20download\x20audio.\x20Please\x20try\x20again\x20later.');
        }
    } catch (_0x22d83a) {
        console[_0x3c1da2(0xc1)](_0x3c1da2(0xb7), _0x22d83a), await _0x419a78[_0x3c1da2(0xcd)](_0x3c1da2(0xd0)), await _0x419a78[_0x3c1da2(0xbc)]('❌');
    }
};
export default test;
