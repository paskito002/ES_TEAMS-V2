(function (_0x54ef06, _0x396b37) {
    const _0x3dc76a = _0x51d2, _0x1b7548 = _0x54ef06();
    while (!![]) {
        try {
            const _0x1da99d = parseInt(_0x3dc76a(0x84)) / 0x1 + parseInt(_0x3dc76a(0x80)) / 0x2 * (parseInt(_0x3dc76a(0xa5)) / 0x3) + -parseInt(_0x3dc76a(0x97)) / 0x4 * (parseInt(_0x3dc76a(0x83)) / 0x5) + -parseInt(_0x3dc76a(0x92)) / 0x6 * (parseInt(_0x3dc76a(0x7e)) / 0x7) + parseInt(_0x3dc76a(0x9f)) / 0x8 * (-parseInt(_0x3dc76a(0x98)) / 0x9) + -parseInt(_0x3dc76a(0xa7)) / 0xa + parseInt(_0x3dc76a(0x8b)) / 0xb;
            if (_0x1da99d === _0x396b37)
                break;
            else
                _0x1b7548['push'](_0x1b7548['shift']());
        } catch (_0x5f2427) {
            _0x1b7548['push'](_0x1b7548['shift']());
        }
    }
}(_0x49e2, 0x57be9));
import _0x39f2dd from '../../set.cjs';
function _0x49e2() {
    const _0x13ba9b = [
        'json',
        'pushName',
        'sendMessage',
        '6CXMydh',
        'error',
        '>\x20*©𝟐𝟎𝟐𝟒\x20ᴇꜱ-ᴛᴇᴀᴍꜱ\x20👑\x20𝐕3*',
        'match',
        'includes',
        '1534476eSzgbr',
        '2547nmXmtd',
        'startsWith',
        'test',
        'xnxxvideo',
        'status',
        'Error\x20fetching\x20video:',
        'Hello\x20_*',
        '16504gYohUX',
        'No\x20results\x20found\x20for\x20the\x20query:\x20',
        'xnxxvideosdl',
        'from',
        'data',
        'download',
        '1116IruAgc',
        'xnxxvidsdl',
        '831160COYNvy',
        'split',
        '3200953iNoNFd',
        'length',
        '2486dewefs',
        'xnxx',
        'success\x20✅',
        '5AFrlqN',
        '549622vwsYcn',
        'sender',
        'datax',
        'link',
        'slice',
        'reply',
        'xnxxvideodl',
        '9407486JZJRae',
        'xnxxvideos',
        'trim',
        'body'
    ];
    _0x49e2 = function () {
        return _0x13ba9b;
    };
    return _0x49e2();
}
import _0x5c6f84 from 'node-fetch';
function _0x51d2(_0x12518a, _0x556190) {
    const _0x49e246 = _0x49e2();
    return _0x51d2 = function (_0x51d22d, _0x2adb9b) {
        _0x51d22d = _0x51d22d - 0x7e;
        let _0xf14d89 = _0x49e246[_0x51d22d];
        return _0xf14d89;
    }, _0x51d2(_0x12518a, _0x556190);
}
const XnxxvidsDl = async (_0x21fe22, _0x1acb80) => {
    const _0x2cb54a = _0x51d2, _0x1f9ce9 = await _0x1acb80['decodeJid'](_0x1acb80['user']['id']), _0x13e857 = [
            _0x1f9ce9,
            _0x39f2dd['OWNER_NUMBER'] + '@s.whatsapp.net'
        ][_0x2cb54a(0x96)](_0x21fe22[_0x2cb54a(0x85)]), _0x116d36 = _0x21fe22[_0x2cb54a(0x8e)][_0x2cb54a(0x95)](/^[\\/!#.]/), _0x4d9735 = _0x116d36 ? _0x116d36[0x0] : '/', _0x85a548 = _0x21fe22[_0x2cb54a(0x8e)][_0x2cb54a(0x99)](_0x4d9735) ? _0x21fe22[_0x2cb54a(0x8e)][_0x2cb54a(0x88)](_0x4d9735['length'])[_0x2cb54a(0xa8)]('\x20')[0x0]['toLowerCase']() : '', _0x220f3a = _0x21fe22[_0x2cb54a(0x8e)][_0x2cb54a(0x88)](_0x4d9735[_0x2cb54a(0x7f)] + _0x85a548[_0x2cb54a(0x7f)])[_0x2cb54a(0x8d)](), _0x44244c = [
            'xnxxvids',
            _0x2cb54a(0xa6),
            _0x2cb54a(0x9b),
            _0x2cb54a(0x8a),
            _0x2cb54a(0x8c),
            _0x2cb54a(0xa1),
            _0x2cb54a(0x81),
            'xnxxviddl'
        ];
    if (_0x44244c[_0x2cb54a(0x96)](_0x85a548)) {
        if (!_0x13e857)
            return _0x21fe22['reply']('*📛\x20THIS\x20IS\x20AN\x20OWNER\x20COMMAND*');
        if (!_0x220f3a)
            return _0x21fe22[_0x2cb54a(0x89)](_0x2cb54a(0x9e) + _0x21fe22[_0x2cb54a(0x90)] + '*_\x20Please\x20insert\x20a\x20valid\x20Xnxx-Video\x20Link\x20or\x20Search\x20Query!\x20\x0aEg.\x20.xnxx\x20https://www.xnxx.com/video-x2uttb2/fucking_with_the_neighbor\x20or\x20\x0a.xnxx\x20mom\x20and\x20son\x20hot');
        try {
            let _0x36f4f6 = '';
            const _0x6919b8 = /(https?:\/\/[^\s]+)/;
            if (_0x6919b8[_0x2cb54a(0x9a)](_0x220f3a))
                _0x36f4f6 = _0x220f3a;
            else {
                const _0x372c72 = await _0x5c6f84('https://api.prabath-md.tech/api/xnxxsearch?q=' + encodeURIComponent(_0x220f3a)), _0x5011a2 = await _0x372c72[_0x2cb54a(0x8f)]();
                if (_0x5011a2[_0x2cb54a(0x9c)] === _0x2cb54a(0x82) && _0x5011a2[_0x2cb54a(0xa3)] && _0x5011a2[_0x2cb54a(0xa3)][_0x2cb54a(0x86)] && _0x5011a2[_0x2cb54a(0xa3)][_0x2cb54a(0x86)]['length'] > 0x0)
                    _0x36f4f6 = _0x5011a2[_0x2cb54a(0xa3)][_0x2cb54a(0x86)][0x0][_0x2cb54a(0x87)];
                else
                    return _0x21fe22[_0x2cb54a(0x89)](_0x2cb54a(0xa0) + _0x220f3a);
            }
            const _0x330e53 = await _0x5c6f84('https://api.prabath-md.tech/api/xnxxdl?url=' + _0x36f4f6), _0x2c9fd4 = await _0x330e53[_0x2cb54a(0x8f)]();
            if (_0x2c9fd4 && _0x2c9fd4[_0x2cb54a(0xa3)] && _0x2c9fd4[_0x2cb54a(0xa3)][_0x2cb54a(0xa4)]) {
                const _0x242e39 = _0x2c9fd4['data'][_0x2cb54a(0xa4)];
                await _0x21fe22['reply']('A\x20moment,\x20*Gifted-Md*\x20is\x20Downloading\x20Your\x20+18\x20video,\x20Please\x20Wait...'), await _0x1acb80['sendMessage'](_0x21fe22['from'], {
                    'video': { 'url': _0x242e39 },
                    'caption': _0x2cb54a(0x94),
                    'gifPlayback': ![]
                }, { 'quoted': _0x21fe22 });
            } else
                await _0x1acb80[_0x2cb54a(0x91)](_0x21fe22[_0x2cb54a(0xa2)], { 'text': 'Failed\x20to\x20retrieve\x20the\x20video.\x20Please\x20try\x20again\x20later.' }, { 'quoted': _0x21fe22 });
        } catch (_0x1724c) {
            console[_0x2cb54a(0x93)](_0x2cb54a(0x9d), _0x1724c), await _0x1acb80['sendMessage'](_0x21fe22[_0x2cb54a(0xa2)], { 'text': 'Failed\x20to\x20retrieve\x20the\x20video.\x20Please\x20try\x20again\x20later.' }, { 'quoted': _0x21fe22 });
        }
    }
};
export default XnxxvidsDl;
