(function (_0x3e352e, _0x532bc3) {
    const _0x3e34f5 = _0x3d06, _0x210f9c = _0x3e352e();
    while (!![]) {
        try {
            const _0x37fbe3 = -parseInt(_0x3e34f5(0x1ca)) / 0x1 * (parseInt(_0x3e34f5(0x1e3)) / 0x2) + -parseInt(_0x3e34f5(0x1e2)) / 0x3 * (parseInt(_0x3e34f5(0x1c8)) / 0x4) + parseInt(_0x3e34f5(0x1e7)) / 0x5 * (parseInt(_0x3e34f5(0x205)) / 0x6) + -parseInt(_0x3e34f5(0x1e4)) / 0x7 * (parseInt(_0x3e34f5(0x1f4)) / 0x8) + parseInt(_0x3e34f5(0x1f8)) / 0x9 + -parseInt(_0x3e34f5(0x1d1)) / 0xa + parseInt(_0x3e34f5(0x1fa)) / 0xb;
            if (_0x37fbe3 === _0x532bc3)
                break;
            else
                _0x210f9c['push'](_0x210f9c['shift']());
        } catch (_0x57bb5a) {
            _0x210f9c['push'](_0x210f9c['shift']());
        }
    }
}(_0x2ed0, 0xa2327));
import _0x51f2c7 from 'axios';
function _0x2ed0() {
    const _0x3e5d13 = [
        '🏙️Production\x20:\x20',
        '⚍⚎⚎⚎⚎⚎⚎⚎⚎⚎⚎⚎⚎⚎⚎⚍\x0a',
        'slice',
        'Year',
        '🌀Genre\x20\x20\x20\x20\x20\x20:\x20',
        'Genre',
        '8fhESgF',
        '📦BoxOffice\x20\x20:\x20',
        '⭐Rated\x20\x20\x20\x20\x20\x20:\x20',
        '\x20```ᴇꜱ-ᴛᴇᴀᴍꜱ\x20MOVIE\x20SEARCH```\x0a',
        '4001319oVtsNw',
        'error',
        '16927097DZGYqh',
        '📆Released\x20\x20\x20:\x20',
        'reply',
        'data',
        '⏳Runtime\x20\x20\x20\x20:\x20',
        'sendMessage',
        'False',
        '🌍Country\x20\x20\x20\x20:\x20',
        '✅imdbVotes\x20\x20:\x20',
        'Actors',
        'Response',
        '18PLZTaZ',
        '👨Actors\x20\x20\x20\x20\x20:\x20',
        '⚎⚎⚎⚎⚎⚎⚎⚎⚎⚎⚎⚎⚎⚎⚎⚎\x0a',
        'Poster',
        '🎖️Awards\x20\x20\x20\x20\x20:\x20',
        'length',
        'Released',
        '880bZWhCt',
        'Error:',
        '312824VfWhSr',
        'imdbVotes',
        'from',
        'imdb',
        'imdbRating',
        'An\x20error\x20occurred\x20while\x20fetching\x20the\x20data.',
        'Rated',
        '8135810qwliRG',
        'Title',
        '✍Writer\x20\x20\x20\x20\x20:\x20',
        'startsWith',
        'http://www.omdbapi.com/?apikey=742b2d09&t=',
        'Language',
        '🎬Title\x20\x20\x20\x20\x20\x20:\x20',
        '🌐Language\x20\x20\x20:\x20',
        'split',
        'Plot',
        'Awards',
        'match',
        '📅Year\x20\x20\x20\x20\x20\x20\x20:\x20',
        '🌟imdbRating\x20:\x20',
        'body',
        'Production',
        'Give\x20me\x20a\x20series\x20or\x20movie\x20name',
        '4644wJtTyu',
        '4ZKwiUH',
        '1392391sFCrRr',
        'movie',
        'toLowerCase',
        '1099405iQIZWp',
        'Country',
        'BoxOffice',
        'Writer',
        'get',
        '👨🏻‍💻Director\x20\x20\x20:\x20',
        'Director'
    ];
    _0x2ed0 = function () {
        return _0x3e5d13;
    };
    return _0x2ed0();
}
const imdb = async (_0x5a78ef, _0x598828) => {
    const _0x621c99 = _0x3d06;
    try {
        const _0x508c08 = _0x5a78ef[_0x621c99(0x1df)][_0x621c99(0x1dc)](/^[\\/!#.]/), _0xb69cbc = _0x508c08 ? _0x508c08[0x0] : '/', _0x5a8f24 = _0x5a78ef[_0x621c99(0x1df)][_0x621c99(0x1d4)](_0xb69cbc) ? _0x5a78ef['body'][_0x621c99(0x1f0)](_0xb69cbc[_0x621c99(0x1c6)])[_0x621c99(0x1d9)]('\x20')[0x0][_0x621c99(0x1e6)]() : '', _0x24154a = _0x5a78ef[_0x621c99(0x1df)][_0x621c99(0x1f0)](_0xb69cbc[_0x621c99(0x1c6)] + _0x5a8f24[_0x621c99(0x1c6)])['trim'](), _0x15db5d = [
                _0x621c99(0x1e5),
                _0x621c99(0x1cd)
            ];
        if (!_0x15db5d['includes'](_0x5a8f24))
            return;
        if (!_0x24154a)
            return _0x5a78ef[_0x621c99(0x1fc)](_0x621c99(0x1e1));
        let _0x358924 = await _0x51f2c7[_0x621c99(0x1eb)](_0x621c99(0x1d5) + encodeURIComponent(_0x24154a) + '&plot=full'), _0x3e685c = '';
        if (_0x358924['data'][_0x621c99(0x204)] === _0x621c99(0x200))
            return _0x5a78ef[_0x621c99(0x1fc)]('Movie\x20or\x20series\x20not\x20found');
        _0x3e685c += _0x621c99(0x1ef), _0x3e685c += _0x621c99(0x1f7), _0x3e685c += _0x621c99(0x207), _0x3e685c += _0x621c99(0x1d7) + _0x358924[_0x621c99(0x1fd)][_0x621c99(0x1d2)] + '\x0a', _0x3e685c += _0x621c99(0x1dd) + _0x358924['data'][_0x621c99(0x1f1)] + '\x0a', _0x3e685c += _0x621c99(0x1f6) + _0x358924[_0x621c99(0x1fd)][_0x621c99(0x1d0)] + '\x0a', _0x3e685c += _0x621c99(0x1fb) + _0x358924[_0x621c99(0x1fd)][_0x621c99(0x1c7)] + '\x0a', _0x3e685c += _0x621c99(0x1fe) + _0x358924[_0x621c99(0x1fd)]['Runtime'] + '\x0a', _0x3e685c += _0x621c99(0x1f2) + _0x358924[_0x621c99(0x1fd)][_0x621c99(0x1f3)] + '\x0a', _0x3e685c += _0x621c99(0x1ec) + _0x358924[_0x621c99(0x1fd)][_0x621c99(0x1ed)] + '\x0a', _0x3e685c += _0x621c99(0x1d3) + _0x358924[_0x621c99(0x1fd)][_0x621c99(0x1ea)] + '\x0a', _0x3e685c += _0x621c99(0x206) + _0x358924[_0x621c99(0x1fd)][_0x621c99(0x203)] + '\x0a', _0x3e685c += '📃Plot\x20\x20\x20\x20\x20\x20\x20:\x20' + _0x358924[_0x621c99(0x1fd)][_0x621c99(0x1da)] + '\x0a', _0x3e685c += _0x621c99(0x1d8) + _0x358924['data'][_0x621c99(0x1d6)] + '\x0a', _0x3e685c += _0x621c99(0x201) + _0x358924[_0x621c99(0x1fd)][_0x621c99(0x1e8)] + '\x0a', _0x3e685c += _0x621c99(0x1c5) + _0x358924[_0x621c99(0x1fd)][_0x621c99(0x1db)] + '\x0a', _0x3e685c += _0x621c99(0x1f5) + _0x358924[_0x621c99(0x1fd)][_0x621c99(0x1e9)] + '\x0a', _0x3e685c += _0x621c99(0x1ee) + _0x358924[_0x621c99(0x1fd)][_0x621c99(0x1e0)] + '\x0a', _0x3e685c += _0x621c99(0x1de) + _0x358924[_0x621c99(0x1fd)][_0x621c99(0x1ce)] + '\x0a', _0x3e685c += _0x621c99(0x202) + _0x358924[_0x621c99(0x1fd)][_0x621c99(0x1cb)] + '\x0a', await _0x598828[_0x621c99(0x1ff)](_0x5a78ef[_0x621c99(0x1cc)], {
            'image': { 'url': _0x358924[_0x621c99(0x1fd)][_0x621c99(0x1c4)] },
            'caption': _0x3e685c
        }, { 'quoted': _0x5a78ef });
    } catch (_0x9e9f26) {
        console[_0x621c99(0x1f9)](_0x621c99(0x1c9), _0x9e9f26), _0x5a78ef[_0x621c99(0x1fc)](_0x621c99(0x1cf));
    }
};
function _0x3d06(_0x35be4c, _0x5c2c51) {
    const _0x2ed0e7 = _0x2ed0();
    return _0x3d06 = function (_0x3d062d, _0x517beb) {
        _0x3d062d = _0x3d062d - 0x1c4;
        let _0x51c619 = _0x2ed0e7[_0x3d062d];
        return _0x51c619;
    }, _0x3d06(_0x35be4c, _0x5c2c51);
}
export default imdb;
