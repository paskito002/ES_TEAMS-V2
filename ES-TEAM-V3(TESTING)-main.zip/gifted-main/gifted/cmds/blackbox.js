(function (_0x36edd0, _0x3e0977) {
    const _0x3ade9a = _0x4107, _0x156013 = _0x36edd0();
    while (!![]) {
        try {
            const _0x5483bf = -parseInt(_0x3ade9a(0x142)) / (-0x68 * -0x5 + 0x481 * 0x2 + -0xb09) + -parseInt(_0x3ade9a(0x16e)) / (-0x3 * 0x5fe + 0x1 * -0x1431 + 0x262d) * (parseInt(_0x3ade9a(0x12a)) / (0x7fb + -0xb * -0x6d + -0x4f * 0x29)) + -parseInt(_0x3ade9a(0x15f)) / (-0x2561 + -0xdcd * 0x2 + 0x40ff) + parseInt(_0x3ade9a(0x131)) / (0x75e + 0xcb8 * 0x1 + -0x1 * 0x1411) + parseInt(_0x3ade9a(0x14c)) / (-0x43 * -0x22 + 0x1173 + 0x1 * -0x1a53) * (-parseInt(_0x3ade9a(0x160)) / (0xd * 0x1af + 0xb6a + -0x2146)) + parseInt(_0x3ade9a(0x171)) / (0x5a * 0x10 + 0x2073 + -0x1 * 0x260b) + -parseInt(_0x3ade9a(0x152)) / (0x5d * -0x5a + -0x5 * 0x409 + -0x1a74 * -0x2);
            if (_0x5483bf === _0x3e0977)
                break;
            else
                _0x156013['push'](_0x156013['shift']());
        } catch (_0x1636c1) {
            _0x156013['push'](_0x156013['shift']());
        }
    }
}(_0x4623, 0x11bc00 + -0xa997c * 0x2 + 0x105c5d));
function _0x4107(_0x55f77c, _0x207371) {
    const _0x31b773 = _0x4623();
    return _0x4107 = function (_0xbf3656, _0x15eeb4) {
        _0xbf3656 = _0xbf3656 - (0x9 * 0x21e + -0x751 * 0x2 + -0x344);
        let _0x329a8d = _0x31b773[_0xbf3656];
        return _0x329a8d;
    }, _0x4107(_0x55f77c, _0x207371);
}
import _0x518334 from 'axios';
function _0x4623() {
    const _0x420d56 = [
        'ing\x20GPT\x20re',
        'ing\x20respon',
        'create',
        'key',
        'split',
        'Body',
        '3FExMpv',
        'Header',
        'blackbox',
        'sponse:',
        'aThbP',
        'from',
        'm\x20the\x20GPT\x20',
        '7204260oqIMCk',
        'sendMessag',
        'API.',
        'error',
        'Footer',
        'MMaTb',
        'slice',
        'eMessage',
        'React',
        'reply',
        'Message',
        'startsWith',
        'a\x20question',
        'toLowerCas',
        'relayMessa',
        'Error\x20gett',
        'FgWdW',
        '12754HaLhsl',
        'Copy\x20Your\x20',
        'remoteJid',
        '\x20𝐕𝟓*',
        'vWfoD',
        'copy_code',
        'blackboxai',
        'data',
        'TetWS',
        'Interactiv',
        '6gmrvDb',
        'slbbG',
        'body',
        'gTtBt',
        'stringify',
        'xt=',
        '8236845kUlOPj',
        'message',
        'trim',
        'NativeFlow',
        'cta_copy',
        'VFliO',
        'Hello\x20*_',
        'Invalid\x20re',
        'uNvQf',
        'lackbox?te',
        'get',
        'oNdTq',
        'sponse\x20fro',
        '1756560FgACGA',
        '5746762JyvGvQ',
        'Code',
        '_,*\x0a\x20Pleas',
        'e\x20provide\x20',
        'pushName',
        'length',
        '\x20ᴇꜱ-ᴛᴇᴀᴍꜱ\x20ᴠ3👑',
        'result',
        'includes',
        'aEDFu',
        'dipe.com/b',
        'se\x20from\x20GP',
        '>\x20>\x20*©𝟐𝟎𝟐𝟒',
        'pxPgu',
        '158252BirQVp',
        'match',
        'https://wi',
        '13371968NPsdUa'
    ];
    _0x4623 = function () {
        return _0x420d56;
    };
    return _0x4623();
}
import _0x176f82, { prepareWAMessageMedia } from 'gifted-baileys';
const {generateWAMessageFromContent, proto} = _0x176f82, gptResponse = async (_0x131e3a, _0x4b3ecd) => {
        const _0xda33c1 = _0x4107, _0x495767 = {
                'aEDFu': function (_0x1f38cc, _0x619cf9) {
                    return _0x1f38cc + _0x619cf9;
                },
                'MMaTb': _0xda33c1(0x12c),
                'uNvQf': _0xda33c1(0x148),
                'FgWdW': function (_0x31ee7c, _0x1dc0cd) {
                    return _0x31ee7c(_0x1dc0cd);
                },
                'TetWS': function (_0x88d73c, _0x350cd6, _0x591af6, _0x5ad4e6) {
                    return _0x88d73c(_0x350cd6, _0x591af6, _0x5ad4e6);
                },
                'VFliO': _0xda33c1(0x16c) + _0xda33c1(0x166) + _0xda33c1(0x145),
                'aThbP': _0xda33c1(0x156),
                'oNdTq': _0xda33c1(0x143) + _0xda33c1(0x161),
                'vWfoD': _0xda33c1(0x147),
                'pxPgu': _0xda33c1(0x159) + _0xda33c1(0x15e) + _0xda33c1(0x130) + _0xda33c1(0x133),
                'slbbG': _0xda33c1(0x140) + _0xda33c1(0x172) + _0xda33c1(0x12d),
                'gTtBt': _0xda33c1(0x140) + _0xda33c1(0x173) + _0xda33c1(0x16b) + 'T.'
            }, _0x513d46 = _0x131e3a[_0xda33c1(0x14e)][_0xda33c1(0x16f)](/^[\\/!#.]/), _0x4df77c = _0x513d46 ? _0x513d46[-0x1191 + 0x17b2 * 0x1 + -0x621] : '/', _0x3bde0b = _0x131e3a[_0xda33c1(0x14e)][_0xda33c1(0x13c)](_0x4df77c) ? _0x131e3a[_0xda33c1(0x14e)][_0xda33c1(0x137)](_0x4df77c[_0xda33c1(0x165)])[_0xda33c1(0x128)]('\x20')[0x193c + -0x2 * -0x10ba + -0x3ab0][_0xda33c1(0x13e) + 'e']() : '', _0x2cef95 = _0x131e3a[_0xda33c1(0x14e)][_0xda33c1(0x137)](_0x495767[_0xda33c1(0x169)](_0x4df77c[_0xda33c1(0x165)], _0x3bde0b[_0xda33c1(0x165)]))[_0xda33c1(0x154)](), _0x18caea = [
                _0x495767[_0xda33c1(0x136)],
                _0x495767[_0xda33c1(0x15a)]
            ];
        if (_0x18caea[_0xda33c1(0x168)](_0x3bde0b)) {
            if (!_0x2cef95)
                return _0x131e3a[_0xda33c1(0x13a)](_0xda33c1(0x158) + _0x131e3a[_0xda33c1(0x164)] + (_0xda33c1(0x162) + _0xda33c1(0x163) + _0xda33c1(0x13d) + '.'));
            try {
                await _0x131e3a[_0xda33c1(0x139)]('🕘');
                const _0xaf0ec2 = _0xda33c1(0x170) + _0xda33c1(0x16a) + _0xda33c1(0x15b) + _0xda33c1(0x151) + _0x495767[_0xda33c1(0x141)](encodeURIComponent, _0x2cef95), _0x4748bb = await _0x518334[_0xda33c1(0x15c)](_0xaf0ec2), _0x601f4f = _0x4748bb[_0xda33c1(0x149)];
                if (_0x601f4f && _0x601f4f[_0xda33c1(0x167)]) {
                    const _0x27fb3c = _0x601f4f[_0xda33c1(0x167)], _0x5a57a1 = _0x27fb3c[_0xda33c1(0x16f)](/```([\s\S]*?)```/);
                    if (_0x5a57a1) {
                        const _0x23fe43 = _0x5a57a1[-0x1bd2 + -0x11e7 + -0x1 * -0x2dba];
                        let _0x17d282 = _0x495767[_0xda33c1(0x14a)](generateWAMessageFromContent, _0x131e3a[_0xda33c1(0x12f)], {
                            'viewOnceMessage': {
                                'message': {
                                    'messageContextInfo': {
                                        'deviceListMetadata': {},
                                        'deviceListMetadataVersion': 0x2
                                    },
                                    'interactiveMessage': proto[_0xda33c1(0x13b)][_0xda33c1(0x14b) + _0xda33c1(0x138)][_0xda33c1(0x174)]({
                                        'body': proto[_0xda33c1(0x13b)][_0xda33c1(0x14b) + _0xda33c1(0x138)][_0xda33c1(0x129)][_0xda33c1(0x174)]({ 'text': _0x27fb3c }),
                                        'footer': proto[_0xda33c1(0x13b)][_0xda33c1(0x14b) + _0xda33c1(0x138)][_0xda33c1(0x135)][_0xda33c1(0x174)]({ 'text': _0x495767[_0xda33c1(0x157)] }),
                                        'header': proto[_0xda33c1(0x13b)][_0xda33c1(0x14b) + _0xda33c1(0x138)][_0xda33c1(0x12b)][_0xda33c1(0x174)]({
                                            'title': '',
                                            'subtitle': '',
                                            'hasMediaAttachment': ![]
                                        }),
                                        'nativeFlowMessage': proto[_0xda33c1(0x13b)][_0xda33c1(0x14b) + _0xda33c1(0x138)][_0xda33c1(0x155) + _0xda33c1(0x13b)][_0xda33c1(0x174)]({
                                            'buttons': [{
                                                    'name': _0x495767[_0xda33c1(0x12e)],
                                                    'buttonParamsJson': JSON[_0xda33c1(0x150)]({
                                                        'display_text': _0x495767[_0xda33c1(0x15d)],
                                                        'id': _0x495767[_0xda33c1(0x146)],
                                                        'copy_code': _0x23fe43
                                                    })
                                                }]
                                        })
                                    })
                                }
                            }
                        }, {});
                        await _0x4b3ecd[_0xda33c1(0x13f) + 'ge'](_0x17d282[_0xda33c1(0x175)][_0xda33c1(0x144)], _0x17d282[_0xda33c1(0x153)], { 'messageId': _0x17d282[_0xda33c1(0x175)]['id'] });
                    } else
                        await _0x4b3ecd[_0xda33c1(0x132) + 'e'](_0x131e3a[_0xda33c1(0x12f)], { 'text': _0x27fb3c }, { 'quoted': _0x131e3a });
                    await _0x131e3a[_0xda33c1(0x139)]('✅');
                } else
                    throw new Error(_0x495767[_0xda33c1(0x16d)]);
            } catch (_0x5cb22f) {
                console[_0xda33c1(0x134)](_0x495767[_0xda33c1(0x14d)], _0x5cb22f[_0xda33c1(0x153)]), _0x131e3a[_0xda33c1(0x13a)](_0x495767[_0xda33c1(0x14f)]), await _0x131e3a[_0xda33c1(0x139)]('❌');
            }
        }
    };
export default gptResponse;
